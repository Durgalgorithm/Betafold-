import React, { useState, useRef } from 'react';
import { ResiduePrediction } from '../types';
import { ChevronRight, Sparkles, CheckCircle2, AlertCircle, Info } from 'lucide-react';

interface SequenceTrackProps {
  residues: ResiduePrediction[];
  selectedResidueIndex: number | null;
  onSelectResidue: (index: number | null) => void;
  q3Accuracy?: number;
  sovScore?: number;
}

export const SequenceTrack: React.FC<SequenceTrackProps> = ({
  residues,
  selectedResidueIndex,
  onSelectResidue,
  q3Accuracy,
  sovScore,
}) => {
  const [activeTab, setActiveTab] = useState<'secondary' | 'probabilities' | 'pssm'>('secondary');
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  const getQ3BadgeStyle = (q3: string) => {
    switch (q3) {
      case 'H':
        return 'bg-rose-500/20 text-rose-400 border-rose-500/40';
      case 'E':
        return 'bg-amber-500/20 text-amber-400 border-amber-500/40';
      case 'C':
      default:
        return 'bg-cyan-500/20 text-cyan-400 border-cyan-500/40';
    }
  };

  return (
    <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-5 shadow-xl">
      {/* Header with track selector and quick stats */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-400">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-slate-100 flex items-center gap-2">
              Residue Sequence Alignment & Secondary Structure Tracks
            </h3>
            <p className="text-xs text-slate-400">
              Per-position prediction, ground-truth DSSP verification, and probability distribution
            </p>
          </div>
        </div>

        {/* Accuracy and SOV indicators */}
        <div className="flex items-center gap-3">
          {q3Accuracy !== undefined && (
            <div className="flex items-center gap-1.5 px-3 py-1 rounded-lg bg-emerald-950/40 border border-emerald-500/30 text-xs">
              <span className="text-slate-400">Q3 Accuracy:</span>
              <span className="font-mono font-bold text-emerald-400">{q3Accuracy}%</span>
            </div>
          )}
          {sovScore !== undefined && (
            <div className="flex items-center gap-1.5 px-3 py-1 rounded-lg bg-sky-950/40 border border-sky-500/30 text-xs">
              <span className="text-slate-400">SOV Score:</span>
              <span className="font-mono font-bold text-sky-400">{sovScore}%</span>
            </div>
          )}

          {/* Track View Mode Selector */}
          <div className="flex items-center bg-slate-800/80 rounded-lg p-0.5 text-xs">
            <button
              onClick={() => setActiveTab('secondary')}
              className={`px-3 py-1 rounded-md transition-all ${
                activeTab === 'secondary'
                  ? 'bg-indigo-600 text-white font-medium'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Structure
            </button>
            <button
              onClick={() => setActiveTab('probabilities')}
              className={`px-3 py-1 rounded-md transition-all ${
                activeTab === 'probabilities'
                  ? 'bg-indigo-600 text-white font-medium'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Probabilities
            </button>
            <button
              onClick={() => setActiveTab('pssm')}
              className={`px-3 py-1 rounded-md transition-all ${
                activeTab === 'pssm'
                  ? 'bg-indigo-600 text-white font-medium'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              PSSM Profile
            </button>
          </div>
        </div>
      </div>

      {/* Horizontally scrollable sequence track container */}
      <div className="mt-4 overflow-x-auto pb-3 custom-scrollbar" ref={scrollContainerRef}>
        <div className="inline-block min-w-full">
          {/* Header Row: Position Index Ruler */}
          <div className="flex items-center mb-1 text-[10px] font-mono text-slate-500 select-none">
            <div className="w-24 shrink-0 font-sans text-xs font-medium text-slate-400">Position</div>
            <div className="flex">
              {residues.map((res) => (
                <div
                  key={`pos-${res.index}`}
                  className="w-7 text-center shrink-0"
                >
                  {res.index % 10 === 0 || res.index === 1 ? res.index : '·'}
                </div>
              ))}
            </div>
          </div>

          {/* Amino Acid Sequence Row */}
          <div className="flex items-center mb-2 select-none">
            <div className="w-24 shrink-0 text-xs font-semibold text-slate-300 flex items-center gap-1.5">
              <span>FASTA Seq</span>
            </div>
            <div className="flex">
              {residues.map((res) => {
                const isSelected = selectedResidueIndex === res.index;
                return (
                  <button
                    key={`aa-${res.index}`}
                    onClick={() => onSelectResidue(isSelected ? null : res.index)}
                    className={`w-7 h-7 shrink-0 flex items-center justify-center font-mono text-xs font-bold rounded transition-all ${
                      isSelected
                        ? 'bg-sky-500 text-white ring-2 ring-sky-300 scale-110 z-10'
                        : 'text-slate-200 hover:bg-slate-800'
                    }`}
                    title={`${res.name} (${res.aminoAcid}) at pos ${res.index}`}
                  >
                    {res.aminoAcid}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Predicted Secondary Structure Q3 Track */}
          <div className="flex items-center mb-2 select-none">
            <div className="w-24 shrink-0 text-xs font-semibold text-slate-300">
              <span>Betafold (Q3)</span>
            </div>
            <div className="flex">
              {residues.map((res) => {
                const isSelected = selectedResidueIndex === res.index;
                return (
                  <div
                    key={`pred-q3-${res.index}`}
                    onClick={() => onSelectResidue(isSelected ? null : res.index)}
                    className={`w-7 h-7 shrink-0 flex items-center justify-center font-mono text-xs font-bold border rounded cursor-pointer transition-all ${getQ3BadgeStyle(
                      res.q3
                    )} ${isSelected ? 'ring-2 ring-white scale-110 z-10' : 'hover:brightness-125'}`}
                    title={`Pos ${res.index} (${res.aminoAcid}): Predicted ${
                      res.q3 === 'H' ? 'Helix' : res.q3 === 'E' ? 'Strand' : 'Coil'
                    } with ${(res.confidence * 100).toFixed(1)}% confidence`}
                  >
                    {res.q3}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Ground Truth Row (if available) */}
          {residues[0]?.groundTruthQ3 && (
            <div className="flex items-center mb-2 select-none">
              <div className="w-24 shrink-0 text-xs font-semibold text-slate-400 flex items-center gap-1">
                <span>DSSP Truth</span>
              </div>
              <div className="flex">
                {residues.map((res) => {
                  const isMatch = res.q3 === res.groundTruthQ3;
                  return (
                    <div
                      key={`gt-q3-${res.index}`}
                      className={`w-7 h-7 shrink-0 flex items-center justify-center font-mono text-xs font-bold border rounded ${getQ3BadgeStyle(
                        res.groundTruthQ3 || 'C'
                      )} opacity-80`}
                      title={`Ground Truth at pos ${res.index}: ${res.groundTruthQ3}`}
                    >
                      {res.groundTruthQ3}
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Verification Match / Misclassification Status Row */}
          {residues[0]?.groundTruthQ3 && (
            <div className="flex items-center mb-3 select-none">
              <div className="w-24 shrink-0 text-[11px] font-medium text-slate-400">
                <span>Verification</span>
              </div>
              <div className="flex">
                {residues.map((res) => {
                  const isMatch = res.q3 === res.groundTruthQ3;
                  return (
                    <div
                      key={`match-${res.index}`}
                      className="w-7 h-5 shrink-0 flex items-center justify-center"
                      title={isMatch ? `Position ${res.index}: Accurate prediction` : `Position ${res.index}: Predicted ${res.q3}, true is ${res.groundTruthQ3}`}
                    >
                      {isMatch ? (
                        <div className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                      ) : (
                        <div className="w-2 h-2 rounded-full bg-rose-500 animate-pulse" />
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Tab View 1: Probabilities Stacked Mini Bars */}
          {activeTab === 'probabilities' && (
            <div className="flex items-center pt-2 border-t border-slate-800">
              <div className="w-24 shrink-0 text-[11px] font-medium text-slate-400">
                <span>H / E / C Dist</span>
              </div>
              <div className="flex items-end h-16">
                {residues.map((res) => {
                  const h = res.q3Probabilities.H;
                  const e = res.q3Probabilities.E;
                  const c = res.q3Probabilities.C;
                  return (
                    <div
                      key={`prob-${res.index}`}
                      className="w-7 h-full shrink-0 flex flex-col justify-end px-1 group cursor-pointer"
                      onClick={() => onSelectResidue(res.index)}
                    >
                      <div className="w-full flex flex-col rounded-sm overflow-hidden bg-slate-800 h-full justify-end">
                        <div
                          style={{ height: `${c * 100}%` }}
                          className="bg-cyan-500/70 group-hover:bg-cyan-400 transition-all"
                          title={`Coil P(C): ${(c * 100).toFixed(1)}%`}
                        />
                        <div
                          style={{ height: `${e * 100}%` }}
                          className="bg-amber-500/80 group-hover:bg-amber-400 transition-all"
                          title={`Strand P(E): ${(e * 100).toFixed(1)}%`}
                        />
                        <div
                          style={{ height: `${h * 100}%` }}
                          className="bg-rose-500/90 group-hover:bg-rose-400 transition-all"
                          title={`Helix P(H): ${(h * 100).toFixed(1)}%`}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Tab View 2: PSSM Conservation Heatmap Track */}
          {activeTab === 'pssm' && (
            <div className="flex items-center pt-2 border-t border-slate-800">
              <div className="w-24 shrink-0 text-[11px] font-medium text-slate-400">
                <span>PSSM Weight</span>
              </div>
              <div className="flex">
                {residues.map((res) => {
                  // Normalize score 1 to 15
                  const intensity = Math.min(1, Math.max(0.1, res.pssmScore / 14));
                  return (
                    <div
                      key={`pssm-${res.index}`}
                      className="w-7 h-6 shrink-0 flex items-center justify-center font-mono text-[10px] font-semibold transition-all hover:ring-1 hover:ring-white cursor-pointer"
                      style={{
                        backgroundColor: `rgba(99, 102, 241, ${intensity})`,
                        color: intensity > 0.5 ? '#ffffff' : '#cbd5e1',
                      }}
                      onClick={() => onSelectResidue(res.index)}
                      title={`Position ${res.index} (${res.aminoAcid}): PSSM Conservation Score ${res.pssmScore}`}
                    >
                      {res.pssmScore}
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Footer Notes & Key */}
      <div className="mt-3 pt-3 border-t border-slate-800/80 flex flex-wrap items-center justify-between text-xs text-slate-400 gap-3">
        <div className="flex items-center gap-4">
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded bg-rose-500" />
            <span>H: Alpha Helix</span>
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded bg-amber-500" />
            <span>E: Beta Strand</span>
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded bg-cyan-400" />
            <span>C: Random Coil / Loop</span>
          </span>
        </div>
        <div className="flex items-center gap-1.5 text-slate-400">
          <Info className="w-3.5 h-3.5 text-sky-400" />
          <span>Click any residue cell to sync with 3D cartoon viewer and active inspection</span>
        </div>
      </div>
    </div>
  );
};
