import React, { useState } from 'react';
import {
  Activity,
  AlertTriangle,
  BookOpen,
  Dna,
  Flame,
  Globe,
  Info,
  Layers,
  MapPin,
  Sparkles,
  Zap
} from 'lucide-react';
import { ProteinSample, ProteinKnowledge, DiseaseImplication } from '../types';

interface ProteinKnowledgeCardProps {
  protein: ProteinSample;
  customSequence?: string;
  isCustomMode: boolean;
  knowledge?: ProteinKnowledge;
  isLoadingKnowledge?: boolean;
  onRefreshKnowledge?: () => void;
}

export const ProteinKnowledgeCard: React.FC<ProteinKnowledgeCardProps> = ({
  protein,
  knowledge,
  isLoadingKnowledge = false,
  onRefreshKnowledge,
}) => {
  const [selectedDiseaseIndex, setSelectedDiseaseIndex] = useState<number>(0);
  const [inSilicoMutation, setInSilicoMutation] = useState<{
    mutationName: string;
    targetMotif: string;
    consequence: string;
    ddgEstimate: string;
  }>({
    mutationName: 'Proline Insertion in α-Helix (Helix Breaker)',
    targetMotif: 'Core Alpha Helix Backbone',
    consequence: 'Lacks amide hydrogen for i → i+4 H-bonding; steric clash from pyrrolidine ring kinks helix by ~30° and prompts local unfolding into random coil.',
    ddgEstimate: '+3.8 kcal/mol (Severe Destabilization)',
  });

  const activeKnowledge = knowledge || protein.knowledge;
  const diseases: DiseaseImplication[] = activeKnowledge?.diseases || [];
  const selectedDisease = diseases[selectedDiseaseIndex] || diseases[0];

  const handleSimulateMutation = (type: 'proline' | 'charge' | 'hydrophobic' | 'cysteine') => {
    switch (type) {
      case 'proline':
        setInSilicoMutation({
          mutationName: 'Proline Insertion in α-Helix (Helix Breaker)',
          targetMotif: 'Core Alpha Helix Backbone',
          consequence: 'Lacks amide hydrogen for i → i+4 H-bonding; steric clash from pyrrolidine ring introduces a ~30° kink, destabilizing the helical dipole and causing local collapse into loop/coil.',
          ddgEstimate: '+3.8 kcal/mol (Severe Destabilization)',
        });
        break;
      case 'charge':
        setInSilicoMutation({
          mutationName: 'Buried Charge Inversion (e.g. Lys/Arg → Asp/Glu or Glu → Val)',
          targetMotif: 'Hydrophobic Core Packing / Salt Bridge',
          consequence: 'Introduces an uncompensated desolvation penalty (~10-15 kcal/mol) in the non-polar interior or breaks critical inter-chain salt bridges, triggering misfolding.',
          ddgEstimate: '+4.5 kcal/mol (Critical Disruption)',
        });
        break;
      case 'hydrophobic':
        setInSilicoMutation({
          mutationName: 'Core Cavity Creation (e.g. Leu/Ile → Ala/Gly)',
          targetMotif: 'Hydrophobic Core Van der Waals Network',
          consequence: 'Truncating bulky aliphatic side-chains leaves an unfillable vacuum cavity (~20-24 Å³ per -CH2-), weakening hydrophobic collapse and promoting transient partial unfolding.',
          ddgEstimate: '+2.1 kcal/mol (Moderate Destabilization)',
        });
        break;
      case 'cysteine':
        setInSilicoMutation({
          mutationName: 'Disulfide Crosslink Loss (Cys → Ser/Ala)',
          targetMotif: 'Covalent Disulfide Bridge (Cys-Cys)',
          consequence: 'Eliminates conformational entropy restriction of the unfolded state; drastically lowers thermal melting point (Tm drops by 15-25°C) and promotes toxic fibril aggregation.',
          ddgEstimate: '+5.2 kcal/mol (Extreme Destabilization)',
        });
        break;
    }
  };

  return (
    <div id="protein-knowledge-card" className="bg-slate-900/80 border border-slate-800 rounded-xl p-6 text-slate-200">
      {/* Header with Title and Badges */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-5 border-b border-slate-800/80">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-lg bg-cyan-500/10 border border-cyan-500/25 text-cyan-400">
            <BookOpen className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-lg font-semibold text-white tracking-tight">
                Biological Knowledge & Clinical Mutation Pathology
              </h3>
              <span className="text-xs px-2 py-0.5 rounded-full bg-cyan-500/10 text-cyan-300 border border-cyan-500/20 font-mono">
                {protein.pdbId || 'PDB'}
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Normal physiological role, structural secondary folding determinants, and disease phenotypes caused by genetic mutations
            </p>
          </div>
        </div>

        {onRefreshKnowledge && (
          <button
            id="btn-refresh-knowledge"
            type="button"
            onClick={onRefreshKnowledge}
            disabled={isLoadingKnowledge}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-slate-700 hover:border-cyan-500/40 transition-colors disabled:opacity-50"
          >
            <Sparkles className={`w-3.5 h-3.5 ${isLoadingKnowledge ? 'animate-spin text-cyan-400' : ''}`} />
            {isLoadingKnowledge ? 'Analyzing Pathology...' : 'Update Biological Analysis'}
          </button>
        )}
      </div>

      {/* Basic Knowledge Overview Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 my-5">
        <div className="bg-slate-950/60 border border-slate-800/80 rounded-lg p-3.5">
          <div className="flex items-center gap-2 text-xs font-medium text-slate-400 mb-1">
            <Globe className="w-3.5 h-3.5 text-emerald-400" />
            Biological Pathway & Role
          </div>
          <div className="text-sm font-semibold text-slate-100">
            {activeKnowledge?.biologicalRole || 'Essential Macromolecular Homeostasis'}
          </div>
          <div className="text-xs text-slate-400 mt-1">
            Organism: <span className="text-slate-300 italic">{protein.organism || 'Biological Origin'}</span>
          </div>
        </div>

        <div className="bg-slate-950/60 border border-slate-800/80 rounded-lg p-3.5">
          <div className="flex items-center gap-2 text-xs font-medium text-slate-400 mb-1">
            <MapPin className="w-3.5 h-3.5 text-cyan-400" />
            Cellular Localization
          </div>
          <div className="text-sm font-semibold text-slate-100">
            {activeKnowledge?.cellularLocation || 'Intracellular / Cytoplasmic'}
          </div>
          <div className="text-xs text-slate-400 mt-1">
            Chain: <span className="text-slate-300 font-mono">{protein.chain || 'A'}</span> • Length:{' '}
            <span className="text-slate-300 font-mono">{protein.sequence.length} aa</span>
          </div>
        </div>

        <div className="bg-slate-950/60 border border-slate-800/80 rounded-lg p-3.5">
          <div className="flex items-center gap-2 text-xs font-medium text-slate-400 mb-1">
            <Layers className="w-3.5 h-3.5 text-indigo-400" />
            Secondary Structure Architecture
          </div>
          <div className="text-xs text-slate-300 line-clamp-3 leading-relaxed">
            {activeKnowledge?.structuralFeatures ||
              'Coordinated assembly of alpha-helices, beta-sheets, and loop segments maintaining hydrophobic core stability.'}
          </div>
        </div>
      </div>

      {/* Function Summary Section */}
      <div className="bg-cyan-950/20 border border-cyan-500/20 rounded-lg p-4 mb-6">
        <div className="flex items-start gap-2.5">
          <Info className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
          <div className="text-xs text-slate-300 leading-relaxed">
            <span className="font-semibold text-cyan-200">Normal Biological Function: </span>
            {activeKnowledge?.functionSummary ||
              protein.description ||
              'Performs essential structural or biochemical catalysis required for cellular life.'}
          </div>
        </div>
      </div>

      {/* Disease and Mutation Pathologies Section */}
      <div className="mb-6">
        <div className="flex items-center justify-between gap-2 mb-3">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-rose-400" />
            <h4 className="text-sm font-semibold text-white">
              Diseases & Pathologies Caused by Mutations
            </h4>
          </div>
          <span className="text-xs text-slate-400">
            {diseases.length} Documented Mutation Case{diseases.length === 1 ? '' : 's'}
          </span>
        </div>

        {diseases.length > 0 ? (
          <div className="space-y-3">
            {/* Disease Selector Tabs */}
            <div className="flex flex-wrap gap-2">
              {diseases.map((d, idx) => (
                <button
                  key={idx}
                  id={`btn-disease-tab-${idx}`}
                  type="button"
                  onClick={() => setSelectedDiseaseIndex(idx)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all flex items-center gap-2 ${
                    selectedDiseaseIndex === idx
                      ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40 shadow-sm'
                      : 'bg-slate-800/80 text-slate-400 hover:text-slate-200 hover:bg-slate-800 border border-slate-700/60'
                  }`}
                >
                  <span
                    className={`w-1.5 h-1.5 rounded-full ${
                      d.severity === 'Severe'
                        ? 'bg-rose-500'
                        : d.severity === 'Moderate'
                        ? 'bg-amber-400'
                        : 'bg-blue-400'
                    }`}
                  />
                  {d.diseaseName}
                </button>
              ))}
            </div>

            {/* Active Disease Detailed Breakdown */}
            {selectedDisease && (
              <div className="bg-slate-950/70 border border-slate-800 rounded-xl p-4 transition-all">
                <div className="flex flex-wrap items-center justify-between gap-2 mb-3 pb-3 border-b border-slate-800">
                  <div>
                    <h5 className="text-sm font-bold text-rose-300 flex items-center gap-2">
                      {selectedDisease.diseaseName}
                    </h5>
                    <div className="text-xs text-slate-400 mt-0.5">
                      Mutation: <span className="font-mono text-slate-200">{selectedDisease.mutationType}</span>
                    </div>
                  </div>
                  <span
                    className={`text-xs px-2.5 py-1 rounded-full font-medium border ${
                      selectedDisease.severity === 'Severe'
                        ? 'bg-rose-500/15 text-rose-300 border-rose-500/30'
                        : selectedDisease.severity === 'Moderate'
                        ? 'bg-amber-500/15 text-amber-300 border-amber-500/30'
                        : 'bg-blue-500/15 text-blue-300 border-blue-500/30'
                    }`}
                  >
                    Clinical Severity: {selectedDisease.severity}
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                  <div className="bg-slate-900/60 rounded-lg p-3 border border-slate-800/80">
                    <div className="font-semibold text-slate-300 flex items-center gap-1.5 mb-1.5">
                      <Activity className="w-3.5 h-3.5 text-rose-400" />
                      Clinical Impact & Symptoms:
                    </div>
                    <p className="text-slate-300 leading-relaxed">
                      {selectedDisease.clinicalImpact}
                    </p>
                  </div>

                  <div className="bg-slate-900/60 rounded-lg p-3 border border-slate-800/80">
                    <div className="font-semibold text-slate-300 flex items-center gap-1.5 mb-1.5">
                      <Dna className="w-3.5 h-3.5 text-cyan-400" />
                      Molecular & Structural Mechanism:
                    </div>
                    <p className="text-slate-300 leading-relaxed">
                      {selectedDisease.structuralMechanism}
                    </p>
                  </div>
                </div>
              </div>
            )}
          </div>
        ) : (
          <div className="text-xs text-slate-400 p-4 bg-slate-950/40 rounded-lg border border-slate-800">
            No specific clinical disease records found for this sequence. Mutations in core secondary structure elements frequently lead to non-functional misfolded conformers or accelerated intracellular degradation.
          </div>
        )}
      </div>

      {/* In Silico Mutagenesis & Structure Impact Simulator */}
      <div className="mt-6 pt-5 border-t border-slate-800">
        <div className="flex items-center justify-between gap-2 mb-3">
          <div className="flex items-center gap-2">
            <Zap className="w-4 h-4 text-amber-400" />
            <h4 className="text-sm font-semibold text-white">
              In Silico Mutagenesis & Secondary Structure Disruption
            </h4>
          </div>
          <span className="text-xs text-amber-400/90 font-mono flex items-center gap-1">
            <Flame className="w-3 h-3" /> Biophysical Simulation
          </span>
        </div>

        <p className="text-xs text-slate-400 mb-3 leading-relaxed">
          Select a common pathogenic mutation archetype to observe how amino acid substitution dismantles the secondary structure backbone:
        </p>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-3">
          <button
            id="btn-mutation-proline"
            type="button"
            onClick={() => handleSimulateMutation('proline')}
            className={`px-2.5 py-2 rounded-lg text-xs font-medium text-left border transition-all ${
              inSilicoMutation.mutationName.includes('Proline')
                ? 'bg-amber-500/15 border-amber-500/40 text-amber-300 shadow-sm'
                : 'bg-slate-800/70 border-slate-700/60 text-slate-300 hover:bg-slate-800'
            }`}
          >
            <div className="font-semibold">Helix Breaker</div>
            <div className="text-[11px] text-slate-400 mt-0.5">Xaa → Proline</div>
          </button>

          <button
            id="btn-mutation-charge"
            type="button"
            onClick={() => handleSimulateMutation('charge')}
            className={`px-2.5 py-2 rounded-lg text-xs font-medium text-left border transition-all ${
              inSilicoMutation.mutationName.includes('Charge')
                ? 'bg-amber-500/15 border-amber-500/40 text-amber-300 shadow-sm'
                : 'bg-slate-800/70 border-slate-700/60 text-slate-300 hover:bg-slate-800'
            }`}
          >
            <div className="font-semibold">Buried Charge</div>
            <div className="text-[11px] text-slate-400 mt-0.5">Core Hydrophobic → Polar</div>
          </button>

          <button
            id="btn-mutation-hydrophobic"
            type="button"
            onClick={() => handleSimulateMutation('hydrophobic')}
            className={`px-2.5 py-2 rounded-lg text-xs font-medium text-left border transition-all ${
              inSilicoMutation.mutationName.includes('Cavity')
                ? 'bg-amber-500/15 border-amber-500/40 text-amber-300 shadow-sm'
                : 'bg-slate-800/70 border-slate-700/60 text-slate-300 hover:bg-slate-800'
            }`}
          >
            <div className="font-semibold">Cavity Formation</div>
            <div className="text-[11px] text-slate-400 mt-0.5">Leu/Ile → Ala Truncation</div>
          </button>

          <button
            id="btn-mutation-cysteine"
            type="button"
            onClick={() => handleSimulateMutation('cysteine')}
            className={`px-2.5 py-2 rounded-lg text-xs font-medium text-left border transition-all ${
              inSilicoMutation.mutationName.includes('Disulfide')
                ? 'bg-amber-500/15 border-amber-500/40 text-amber-300 shadow-sm'
                : 'bg-slate-800/70 border-slate-700/60 text-slate-300 hover:bg-slate-800'
            }`}
          >
            <div className="font-semibold">Disulfide Loss</div>
            <div className="text-[11px] text-slate-400 mt-0.5">Cys → Ser/Ala</div>
          </button>
        </div>

        <div className="bg-slate-950/80 border border-slate-800 rounded-lg p-3.5 text-xs">
          <div className="flex flex-wrap items-center justify-between gap-2 pb-2 mb-2 border-b border-slate-800/80">
            <div className="font-semibold text-amber-300">
              {inSilicoMutation.mutationName}
            </div>
            <span className="font-mono text-rose-400 font-semibold bg-rose-500/10 px-2 py-0.5 rounded border border-rose-500/20">
              ΔΔG: {inSilicoMutation.ddgEstimate}
            </span>
          </div>

          <div className="space-y-1.5 text-slate-300">
            <div>
              <span className="text-slate-400">Target Structural Motif: </span>
              <span className="text-slate-200 font-mono">{inSilicoMutation.targetMotif}</span>
            </div>
            <div>
              <span className="text-slate-400">Biophysical Folding Consequence: </span>
              <span className="text-slate-200 leading-relaxed">{inSilicoMutation.consequence}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
