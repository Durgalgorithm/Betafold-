import React, { useEffect, useRef, useState, useCallback } from 'react';
import { ResiduePrediction, ExperimentalStructureData } from '../types';
import { generatePredictedPdbText } from '../utils/bioinformatics';
import { get3Dmol } from '../utils/mol3d';
import {
  Columns2,
  Layers,
  Eye,
  RotateCw,
  ZoomIn,
  ZoomOut,
  RefreshCw,
  Camera,
  Download,
  Sparkles,
  Link,
  Unlink,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';

export type ViewMode = 'split' | 'overlaid' | 'predicted' | 'experimental';
export type RenderStyle = 'cartoon' | 'tube' | 'stick' | 'sphere' | 'surface';
export type ColorScheme = 'secondary' | 'confidence' | 'discrepancy' | 'spectrum';

interface DualMolViewer3DProps {
  residues: ResiduePrediction[];
  experimentalData?: ExperimentalStructureData | null;
  selectedResidueIndex: number | null;
  onSelectResidue: (index: number | null) => void;
  proteinName: string;
  viewMode?: ViewMode;
  onViewModeChange?: (mode: ViewMode) => void;
}

export const DualMolViewer3D: React.FC<DualMolViewer3DProps> = ({
  residues,
  experimentalData,
  selectedResidueIndex,
  onSelectResidue,
  proteinName,
  viewMode: controlledViewMode,
  onViewModeChange,
}) => {
  const [internalViewMode, setInternalViewMode] = useState<ViewMode>('split');
  const viewMode = controlledViewMode ?? internalViewMode;
  const setViewMode = (mode: ViewMode) => {
    if (onViewModeChange) onViewModeChange(mode);
    else setInternalViewMode(mode);
  };

  const [renderStyle, setRenderStyle] = useState<RenderStyle>('cartoon');
  const [colorScheme, setColorScheme] = useState<ColorScheme>('secondary');
  const [autoRotate, setAutoRotate] = useState<boolean>(true);
  const [isSynced, setIsSynced] = useState<boolean>(true);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [hoveredResidue, setHoveredResidue] = useState<{
    index: number;
    aa: string;
    predQ3: string;
    expQ3?: string;
    confidence: number;
    x: number;
    y: number;
  } | null>(null);

  // Viewer DOM containers
  const leftMountRef = useRef<HTMLDivElement>(null);
  const rightMountRef = useRef<HTMLDivElement>(null);
  const overlayMountRef = useRef<HTMLDivElement>(null);

  // 3Dmol viewer instances
  const leftViewerRef = useRef<any>(null);
  const rightViewerRef = useRef<any>(null);
  const overlayViewerRef = useRef<any>(null);

  // Stored model references for instant updates
  const leftModelRef = useRef<any>(null);
  const rightModelRef = useRef<any>(null);
  const overlayPredModelRef = useRef<any>(null);
  const overlayExpModelRef = useRef<any>(null);

  // Animation frame id for auto-spin
  const animFrameRef = useRef<number | null>(null);
  const isInteractingRef = useRef<boolean>(false);

  // Generate predicted PDB string
  const predictedPdbText = React.useMemo(() => {
    return generatePredictedPdbText(residues);
  }, [residues]);

  // Apply visual styling to a 3Dmol viewer model
  const applyModelStyle = useCallback(
    (viewer: any, model: any, isPredicted: boolean) => {
      if (!viewer || !model) return;

      viewer.removeAllSurfaces();

      const baseOpacity = isPredicted ? 0.92 : 0.96;

      if (renderStyle === 'cartoon') {
        // By default set cartoon
        model.setStyle({}, { cartoon: { opacity: baseOpacity, thickness: 0.4 } });

        // Apply secondary structure or confidence coloring
        if (colorScheme === 'secondary') {
          if (isPredicted) {
            residues.forEach((res) => {
              const hex = res.q3 === 'H' ? '#f43f5e' : res.q3 === 'E' ? '#f59e0b' : '#06b6d4';
              viewer.setStyle({ resi: res.index, model: model }, { cartoon: { color: hex, opacity: baseOpacity } });
            });
          } else if (experimentalData?.experimentalQ3) {
            const expQ3 = experimentalData.experimentalQ3;
            for (let i = 0; i < expQ3.length; i++) {
              const q = expQ3[i];
              const hex = q === 'H' ? '#10b981' : q === 'E' ? '#a855f7' : '#94a3b8';
              viewer.setStyle({ resi: i + 1, model: model }, { cartoon: { color: hex, opacity: baseOpacity } });
            }
          }
        } else if (colorScheme === 'confidence' && isPredicted) {
          residues.forEach((res) => {
            const hex = res.confidence >= 0.85 ? '#10b981' : res.confidence >= 0.65 ? '#fbbf24' : '#ef4444';
            viewer.setStyle({ resi: res.index, model: model }, { cartoon: { color: hex, opacity: baseOpacity } });
          });
        } else if (colorScheme === 'discrepancy' && experimentalData?.experimentalQ3) {
          const expQ3 = experimentalData.experimentalQ3;
          const len = Math.min(residues.length, expQ3.length);
          for (let i = 0; i < len; i++) {
            const isMatch = residues[i].q3 === expQ3[i];
            const hex = isMatch ? '#10b981' : '#f43f5e';
            viewer.setStyle({ resi: i + 1, model: model }, { cartoon: { color: hex, opacity: baseOpacity } });
          }
        } else if (colorScheme === 'spectrum') {
          model.setStyle({}, { cartoon: { color: 'spectrum', opacity: baseOpacity } });
        }
      } else if (renderStyle === 'tube') {
        model.setStyle({}, { tube: { radius: 0.7, color: isPredicted ? '#38bdf8' : '#10b981' } });
      } else if (renderStyle === 'stick') {
        model.setStyle({}, { stick: { radius: 0.25, colorscheme: 'Jmol' } });
      } else if (renderStyle === 'sphere') {
        model.setStyle({}, { sphere: { scale: 0.35, colorscheme: 'Jmol' } });
      } else if (renderStyle === 'surface') {
        model.setStyle({}, { cartoon: { opacity: 0.4 } });
        try {
          viewer.addSurface(
            1, // VDW surface
            { opacity: 0.75, color: isPredicted ? '#38bdf8' : '#10b981' },
            {},
            model
          );
        } catch {
          // ignore surface error if unsupported in GL context
        }
      }

      // Highlight selected residue if any
      if (selectedResidueIndex !== null) {
        viewer.addStyle(
          { resi: selectedResidueIndex, model: model },
          { stick: { radius: 0.5, color: '#ffffff' }, sphere: { scale: 0.6, color: '#38bdf8' } }
        );
      }

      viewer.render();
    },
    [renderStyle, colorScheme, residues, experimentalData, selectedResidueIndex]
  );

  // Synchronize viewer camera views
  const syncCameras = useCallback((sourceViewer: any, targetViewer: any) => {
    if (!sourceViewer || !targetViewer) return;
    try {
      const view = sourceViewer.getView();
      targetViewer.setView(view);
      targetViewer.render();
    } catch {
      // ignore
    }
  }, []);

  // Initialize 3Dmol viewers once per view mode change
  useEffect(() => {
    let isMounted = true;
    setIsLoading(true);

    get3Dmol()
      .then(($3Dmol) => {
        if (!isMounted) return;

        // 1. Setup Split Mode (Left: Predicted, Right: Experimental)
        if (viewMode === 'split') {
          if (leftMountRef.current) {
            leftMountRef.current.innerHTML = '';
            const vLeft = $3Dmol.createViewer(leftMountRef.current, {
              backgroundColor: '0x090d16',
            });
            leftViewerRef.current = vLeft;

            if (predictedPdbText) {
              const mLeft = vLeft.addModel(predictedPdbText, 'pdb');
              leftModelRef.current = mLeft;
              applyModelStyle(vLeft, mLeft, true);
              vLeft.zoomTo();
              vLeft.render();
            }

            // Set up interaction sync
            leftMountRef.current.onpointerup = () => {
              if (isSynced && rightViewerRef.current) {
                syncCameras(vLeft, rightViewerRef.current);
              }
            };
          }

          if (rightMountRef.current) {
            rightMountRef.current.innerHTML = '';
            const vRight = $3Dmol.createViewer(rightMountRef.current, {
              backgroundColor: '0x090d16',
            });
            rightViewerRef.current = vRight;

            const expPdb = experimentalData?.pdbText || predictedPdbText;
            if (expPdb) {
              const mRight = vRight.addModel(expPdb, 'pdb');
              rightModelRef.current = mRight;
              applyModelStyle(vRight, mRight, false);
              vRight.zoomTo();
              vRight.render();
            }

            rightMountRef.current.onpointerup = () => {
              if (isSynced && leftViewerRef.current) {
                syncCameras(vRight, leftViewerRef.current);
              }
            };
          }
        }

        // 2. Setup Overlaid View Mode
        if (viewMode === 'overlaid' && overlayMountRef.current) {
          overlayMountRef.current.innerHTML = '';
          const vOver = $3Dmol.createViewer(overlayMountRef.current, {
            backgroundColor: '0x090d16',
          });
          overlayViewerRef.current = vOver;

          if (predictedPdbText) {
            const mPred = vOver.addModel(predictedPdbText, 'pdb');
            mPred.setStyle({}, { cartoon: { color: '#06b6d4', opacity: 0.8 } });
            overlayPredModelRef.current = mPred;
          }

          if (experimentalData?.pdbText) {
            const mExp = vOver.addModel(experimentalData.pdbText, 'pdb');
            mExp.setStyle({}, { cartoon: { color: '#10b981', opacity: 0.92 } });
            overlayExpModelRef.current = mExp;
          }

          vOver.zoomTo();
          vOver.render();
        }

        // 3. Setup Single Predicted Mode
        if (viewMode === 'predicted' && leftMountRef.current) {
          leftMountRef.current.innerHTML = '';
          const vPred = $3Dmol.createViewer(leftMountRef.current, {
            backgroundColor: '0x090d16',
          });
          leftViewerRef.current = vPred;
          if (predictedPdbText) {
            const mPred = vPred.addModel(predictedPdbText, 'pdb');
            leftModelRef.current = mPred;
            applyModelStyle(vPred, mPred, true);
            vPred.zoomTo();
            vPred.render();
          }
        }

        // 4. Setup Single Experimental Mode
        if (viewMode === 'experimental' && rightMountRef.current) {
          rightMountRef.current.innerHTML = '';
          const vExp = $3Dmol.createViewer(rightMountRef.current, {
            backgroundColor: '0x090d16',
          });
          rightViewerRef.current = vExp;
          const expPdb = experimentalData?.pdbText || predictedPdbText;
          if (expPdb) {
            const mExp = vExp.addModel(expPdb, 'pdb');
            rightModelRef.current = mExp;
            applyModelStyle(vExp, mExp, false);
            vExp.zoomTo();
            vExp.render();
          }
        }

        setIsLoading(false);
      })
      .catch((err) => {
        console.warn('Could not initialize 3Dmol viewer:', err);
        setIsLoading(false);
      });

    return () => {
      isMounted = false;
    };
  }, [viewMode, isSynced, syncCameras]);

  // Fast in-place model reload when structure data changes (avoids destroying WebGL context)
  useEffect(() => {
    if (viewMode === 'split') {
      if (leftViewerRef.current && predictedPdbText) {
        leftViewerRef.current.removeAllModels();
        const mLeft = leftViewerRef.current.addModel(predictedPdbText, 'pdb');
        leftModelRef.current = mLeft;
        applyModelStyle(leftViewerRef.current, mLeft, true);
        leftViewerRef.current.zoomTo();
        leftViewerRef.current.render();
      }
      if (rightViewerRef.current) {
        rightViewerRef.current.removeAllModels();
        const expPdb = experimentalData?.pdbText || predictedPdbText;
        if (expPdb) {
          const mRight = rightViewerRef.current.addModel(expPdb, 'pdb');
          rightModelRef.current = mRight;
          applyModelStyle(rightViewerRef.current, mRight, false);
          rightViewerRef.current.zoomTo();
          rightViewerRef.current.render();
        }
      }
    } else if (viewMode === 'overlaid' && overlayViewerRef.current) {
      overlayViewerRef.current.removeAllModels();
      if (predictedPdbText) {
        const mPred = overlayViewerRef.current.addModel(predictedPdbText, 'pdb');
        mPred.setStyle({}, { cartoon: { color: '#06b6d4', opacity: 0.8 } });
        overlayPredModelRef.current = mPred;
      }
      if (experimentalData?.pdbText) {
        const mExp = overlayViewerRef.current.addModel(experimentalData.pdbText, 'pdb');
        mExp.setStyle({}, { cartoon: { color: '#10b981', opacity: 0.92 } });
        overlayExpModelRef.current = mExp;
      }
      overlayViewerRef.current.zoomTo();
      overlayViewerRef.current.render();
    } else if (viewMode === 'predicted' && leftViewerRef.current && predictedPdbText) {
      leftViewerRef.current.removeAllModels();
      const mPred = leftViewerRef.current.addModel(predictedPdbText, 'pdb');
      leftModelRef.current = mPred;
      applyModelStyle(leftViewerRef.current, mPred, true);
      leftViewerRef.current.zoomTo();
      leftViewerRef.current.render();
    } else if (viewMode === 'experimental' && rightViewerRef.current) {
      rightViewerRef.current.removeAllModels();
      const expPdb = experimentalData?.pdbText || predictedPdbText;
      if (expPdb) {
        const mExp = rightViewerRef.current.addModel(expPdb, 'pdb');
        rightModelRef.current = mExp;
        applyModelStyle(rightViewerRef.current, mExp, false);
        rightViewerRef.current.zoomTo();
        rightViewerRef.current.render();
      }
    }
  }, [predictedPdbText, experimentalData?.pdbText, viewMode, applyModelStyle]);

  // Fast style re-render when renderStyle, colorScheme, or residue selection changes
  useEffect(() => {
    if (viewMode === 'split') {
      if (leftViewerRef.current && leftModelRef.current) {
        applyModelStyle(leftViewerRef.current, leftModelRef.current, true);
      }
      if (rightViewerRef.current && rightModelRef.current) {
        applyModelStyle(rightViewerRef.current, rightModelRef.current, false);
      }
    } else if (viewMode === 'predicted') {
      if (leftViewerRef.current && leftModelRef.current) {
        applyModelStyle(leftViewerRef.current, leftModelRef.current, true);
      }
    } else if (viewMode === 'experimental') {
      if (rightViewerRef.current && rightModelRef.current) {
        applyModelStyle(rightViewerRef.current, rightModelRef.current, false);
      }
    }
  }, [renderStyle, colorScheme, selectedResidueIndex, applyModelStyle, viewMode]);

  // Handle Auto-Rotation Animation Loop
  useEffect(() => {
    if (!autoRotate) {
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
      return;
    }

    let spinAngle = 0;
    const animate = () => {
      spinAngle += 0.4;

      if (viewMode === 'split') {
        if (leftViewerRef.current) {
          leftViewerRef.current.rotate(0.35, 'y');
          leftViewerRef.current.render();
        }
        if (rightViewerRef.current) {
          rightViewerRef.current.rotate(0.35, 'y');
          rightViewerRef.current.render();
        }
      } else if (viewMode === 'overlaid' && overlayViewerRef.current) {
        overlayViewerRef.current.rotate(0.35, 'y');
        overlayViewerRef.current.render();
      } else if (viewMode === 'predicted' && leftViewerRef.current) {
        leftViewerRef.current.rotate(0.35, 'y');
        leftViewerRef.current.render();
      } else if (viewMode === 'experimental' && rightViewerRef.current) {
        rightViewerRef.current.rotate(0.35, 'y');
        rightViewerRef.current.render();
      }

      animFrameRef.current = requestAnimationFrame(animate);
    };

    animFrameRef.current = requestAnimationFrame(animate);
    return () => {
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
    };
  }, [autoRotate, viewMode]);

  // Controls Handlers
  const handleResetCamera = () => {
    [leftViewerRef.current, rightViewerRef.current, overlayViewerRef.current].forEach((v) => {
      if (v) {
        v.zoomTo();
        v.render();
      }
    });
  };

  const handleZoom = (direction: 'in' | 'out') => {
    const factor = direction === 'in' ? 1.2 : 0.8;
    [leftViewerRef.current, rightViewerRef.current, overlayViewerRef.current].forEach((v) => {
      if (v) {
        v.zoom(factor, 200);
        v.render();
      }
    });
  };

  const downloadScreenshot = () => {
    const activeViewer =
      viewMode === 'overlaid'
        ? overlayViewerRef.current
        : viewMode === 'experimental'
        ? rightViewerRef.current
        : leftViewerRef.current;

    if (!activeViewer) return;
    try {
      const dataUrl = activeViewer.pngURI();
      const a = document.createElement('a');
      a.href = dataUrl;
      a.download = `Betafold_${proteinName}_${viewMode}_structure.png`;
      a.click();
    } catch {
      // ignore
    }
  };

  return (
    <div
      id="dual-mol-viewer-container"
      className="relative w-full h-full min-h-[560px] bg-slate-950 rounded-2xl overflow-hidden border border-slate-800 shadow-2xl flex flex-col"
    >
      {/* Top Header Bar */}
      <div className="bg-slate-900/95 backdrop-blur-md px-4 py-3 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3 z-20">
        {/* Left: View Mode Buttons */}
        <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs">
          <button
            id="view-mode-split"
            onClick={() => setViewMode('split')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-all flex items-center gap-1.5 ${
              viewMode === 'split'
                ? 'bg-indigo-600 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
            title="Side-by-side comparison of Predicted vs Experimental structure"
          >
            <Columns2 className="w-3.5 h-3.5" />
            <span>Split-Screen View</span>
          </button>
          <button
            id="view-mode-overlaid"
            onClick={() => setViewMode('overlaid')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-all flex items-center gap-1.5 ${
              viewMode === 'overlaid'
                ? 'bg-indigo-600 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
            title="Superimpose predicted and experimental structures in a single 3D scene"
          >
            <Layers className="w-3.5 h-3.5" />
            <span>Overlaid Superimposed</span>
          </button>
          <button
            id="view-mode-predicted"
            onClick={() => setViewMode('predicted')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-all flex items-center gap-1.5 ${
              viewMode === 'predicted'
                ? 'bg-indigo-600 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            <Eye className="w-3.5 h-3.5" />
            <span>Predicted Only</span>
          </button>
          <button
            id="view-mode-experimental"
            onClick={() => setViewMode('experimental')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-all flex items-center gap-1.5 ${
              viewMode === 'experimental'
                ? 'bg-indigo-600 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Experimental Only</span>
          </button>
        </div>

        {/* Middle: Style & Color Controls */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Representation Style */}
          <select
            id="render-style-select"
            value={renderStyle}
            onChange={(e) => setRenderStyle(e.target.value as RenderStyle)}
            className="bg-slate-950 border border-slate-700/80 rounded-xl px-2.5 py-1 text-xs text-slate-200 font-medium focus:outline-none focus:ring-1 focus:ring-indigo-500"
          >
            <option value="cartoon">Cartoon Ribbon & Arrows</option>
            <option value="tube">Backbone Tube Trace</option>
            <option value="stick">Stick Wireframe</option>
            <option value="sphere">Spacefill Spheres (VDW)</option>
            <option value="surface">Solvent Accessible Surface</option>
          </select>

          {/* Color Scheme */}
          <select
            id="color-scheme-select"
            value={colorScheme}
            onChange={(e) => setColorScheme(e.target.value as ColorScheme)}
            className="bg-slate-950 border border-slate-700/80 rounded-xl px-2.5 py-1 text-xs text-slate-200 font-medium focus:outline-none focus:ring-1 focus:ring-indigo-500"
          >
            <option value="secondary">Color by Secondary Structure</option>
            <option value="confidence">Color by Neural Confidence</option>
            <option value="discrepancy">Color by Agreement / Discrepancy</option>
            <option value="spectrum">Color by Rainbow Spectrum</option>
          </select>

          {/* Camera Sync Toggle in Split mode */}
          {viewMode === 'split' && (
            <button
              id="toggle-sync-cameras"
              onClick={() => setIsSynced(!isSynced)}
              className={`px-2.5 py-1 rounded-xl text-xs font-semibold border flex items-center gap-1.5 transition-all ${
                isSynced
                  ? 'bg-indigo-500/20 text-indigo-300 border-indigo-500/40'
                  : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-slate-200'
              }`}
              title={isSynced ? 'Camera orbit synchronized between both views' : 'Independent camera navigation'}
            >
              {isSynced ? <Link className="w-3.5 h-3.5" /> : <Unlink className="w-3.5 h-3.5" />}
              <span>{isSynced ? 'Cameras Synced' : 'Independent'}</span>
            </button>
          )}

          {/* Viewer Tools */}
          <div className="flex items-center gap-1 pl-1 border-l border-slate-800">
            <button
              id="toggle-spin-btn"
              onClick={() => setAutoRotate(!autoRotate)}
              className={`p-1.5 rounded-lg border transition-all ${
                autoRotate
                  ? 'bg-sky-500/20 text-sky-400 border-sky-500/30'
                  : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-slate-200'
              }`}
              title={autoRotate ? 'Pause Auto-Spin' : 'Resume Auto-Spin'}
            >
              <RotateCw className={`w-3.5 h-3.5 ${autoRotate ? 'animate-spin' : ''}`} />
            </button>
            <button
              id="zoom-in-btn"
              onClick={() => handleZoom('in')}
              className="p-1.5 rounded-lg bg-slate-950 text-slate-400 border border-slate-800 hover:text-slate-200 transition-all"
              title="Zoom In"
            >
              <ZoomIn className="w-3.5 h-3.5" />
            </button>
            <button
              id="zoom-out-btn"
              onClick={() => handleZoom('out')}
              className="p-1.5 rounded-lg bg-slate-950 text-slate-400 border border-slate-800 hover:text-slate-200 transition-all"
              title="Zoom Out"
            >
              <ZoomOut className="w-3.5 h-3.5" />
            </button>
            <button
              id="reset-cam-btn"
              onClick={handleResetCamera}
              className="p-1.5 rounded-lg bg-slate-950 text-slate-400 border border-slate-800 hover:text-slate-200 transition-all"
              title="Center & Reset View"
            >
              <RefreshCw className="w-3.5 h-3.5" />
            </button>
            <button
              id="snapshot-png-btn"
              onClick={downloadScreenshot}
              className="p-1.5 rounded-lg bg-slate-950 text-slate-400 border border-slate-800 hover:text-slate-200 transition-all"
              title="Export 3D Render Snapshot (.png)"
            >
              <Camera className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Main View Area */}
      <div className="relative flex-1 w-full h-full flex overflow-hidden">
        {/* Loading Indicator */}
        {isLoading && (
          <div className="absolute inset-0 z-30 bg-slate-950/80 backdrop-blur-sm flex flex-col items-center justify-center gap-3">
            <div className="w-8 h-8 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin" />
            <span className="text-xs font-medium text-slate-300">Rendering 3D Molecular Graphics (3Dmol.js)...</span>
          </div>
        )}

        {/* SPLIT VIEW (Side by Side) */}
        {viewMode === 'split' && (
          <div className="w-full h-full flex flex-col md:flex-row divide-y md:divide-y-0 md:divide-x divide-slate-800/80">
            {/* Left Box: Betafold Prediction */}
            <div className="flex-1 relative flex flex-col min-h-[300px] h-full bg-[#090d16]">
              <div className="absolute top-3 left-3 z-10 bg-slate-900/90 backdrop-blur-md px-3 py-1.5 rounded-xl border border-slate-700/60 shadow-lg flex items-center gap-2">
                <div className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-pulse" />
                <span className="text-xs font-semibold text-slate-200">Betafold Prediction (CNN-BiLSTM)</span>
                <span className="text-[10px] font-mono text-cyan-400 px-1.5 py-0.5 rounded bg-cyan-950 border border-cyan-800">
                  Predicted 3D
                </span>
              </div>
              <div ref={leftMountRef} className="w-full flex-1 cursor-grab active:cursor-grabbing" />
            </div>

            {/* Right Box: Experimental PDB Structure */}
            <div className="flex-1 relative flex flex-col min-h-[300px] h-full bg-[#090d16]">
              <div className="absolute top-3 left-3 z-10 bg-slate-900/90 backdrop-blur-md px-3 py-1.5 rounded-xl border border-slate-700/60 shadow-lg flex items-center gap-2">
                <div className="w-2.5 h-2.5 rounded-full bg-emerald-400" />
                <span className="text-xs font-semibold text-slate-200">
                  {experimentalData ? `Experimental PDB (${experimentalData.pdbId})` : 'PDB Ground Truth'}
                </span>
                {experimentalData?.resolution && (
                  <span className="text-[10px] font-mono text-emerald-400 px-1.5 py-0.5 rounded bg-emerald-950 border border-emerald-800">
                    {experimentalData.resolution}
                  </span>
                )}
              </div>
              <div ref={rightMountRef} className="w-full flex-1 cursor-grab active:cursor-grabbing" />
            </div>
          </div>
        )}

        {/* OVERLAID VIEW (Superimposed) */}
        {viewMode === 'overlaid' && (
          <div className="w-full h-full relative bg-[#090d16]">
            <div className="absolute top-3 left-3 z-10 flex flex-wrap items-center gap-3">
              <div className="bg-slate-900/90 backdrop-blur-md px-3 py-1.5 rounded-xl border border-slate-700/60 shadow-lg flex items-center gap-3 text-xs">
                <div className="flex items-center gap-1.5">
                  <span className="w-3 h-3 rounded-full bg-cyan-400 shadow-sm shadow-cyan-400/50" />
                  <span className="text-slate-200 font-medium">Betafold Predicted Fold</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="w-3 h-3 rounded-full bg-emerald-400 shadow-sm shadow-emerald-400/50" />
                  <span className="text-slate-200 font-medium">Experimental Ground Truth</span>
                </div>
              </div>
            </div>
            <div ref={overlayMountRef} className="w-full h-full cursor-grab active:cursor-grabbing" />
          </div>
        )}

        {/* PREDICTED ONLY VIEW */}
        {viewMode === 'predicted' && (
          <div className="w-full h-full relative bg-[#090d16]">
            <div className="absolute top-3 left-3 z-10 bg-slate-900/90 backdrop-blur-md px-3 py-1.5 rounded-xl border border-slate-700/60 shadow-lg flex items-center gap-2 text-xs">
              <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-pulse" />
              <span className="font-semibold text-slate-200">Betafold Predicted Secondary Structure (CNN-BiLSTM)</span>
            </div>
            <div ref={leftMountRef} className="w-full h-full cursor-grab active:cursor-grabbing" />
          </div>
        )}

        {/* EXPERIMENTAL ONLY VIEW */}
        {viewMode === 'experimental' && (
          <div className="w-full h-full relative bg-[#090d16]">
            <div className="absolute top-3 left-3 z-10 bg-slate-900/90 backdrop-blur-md px-3 py-1.5 rounded-xl border border-slate-700/60 shadow-lg flex items-center gap-2 text-xs">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400" />
              <span className="font-semibold text-slate-200">
                {experimentalData ? `Experimental Structure: ${experimentalData.pdbId} (${experimentalData.title})` : 'PDB Experimental Ground Truth'}
              </span>
            </div>
            <div ref={rightMountRef} className="w-full h-full cursor-grab active:cursor-grabbing" />
          </div>
        )}
      </div>

      {/* Bottom Legend Overlay */}
      <div className="bg-slate-900/95 backdrop-blur-md px-4 py-2.5 border-t border-slate-800 flex flex-wrap items-center justify-between gap-4 text-xs z-10">
        {/* Dynamic Color Palette Legend */}
        <div className="flex flex-wrap items-center gap-4">
          {colorScheme === 'secondary' ? (
            <>
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded-full bg-rose-500 shadow-sm shadow-rose-500/50" />
                <span className="text-slate-300 font-medium">Alpha Helix (H)</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded-full bg-amber-500 shadow-sm shadow-amber-500/50" />
                <span className="text-slate-300 font-medium">Beta Strand (E)</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded-full bg-cyan-400 shadow-sm shadow-cyan-400/50" />
                <span className="text-slate-300 font-medium">Random Coil (C)</span>
              </div>
            </>
          ) : colorScheme === 'confidence' ? (
            <>
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded-full bg-emerald-500" />
                <span className="text-slate-300 font-medium">&gt; 85% High Confidence</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded-full bg-amber-400" />
                <span className="text-slate-300 font-medium">65% – 85% Moderate</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded-full bg-rose-500" />
                <span className="text-slate-300 font-medium">&lt; 65% Low</span>
              </div>
            </>
          ) : colorScheme === 'discrepancy' ? (
            <>
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded-full bg-emerald-500" />
                <span className="text-slate-300 font-medium">Concordant (Pred == Exp)</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded-full bg-rose-500" />
                <span className="text-slate-300 font-medium">Discrepancy (Mispredict)</span>
              </div>
            </>
          ) : (
            <div className="flex items-center gap-1.5">
              <span className="w-16 h-2 rounded-full bg-gradient-to-r from-blue-500 via-emerald-400 via-amber-400 to-rose-500" />
              <span className="text-slate-300 font-medium">N-term → C-term</span>
            </div>
          )}
        </div>

        {/* Selected Residue Quick Inspector */}
        {selectedResidueIndex !== null && residues[selectedResidueIndex - 1] && (
          <div className="flex items-center gap-2 bg-slate-950 px-3 py-1 rounded-lg border border-slate-800">
            {(() => {
              const res = residues[selectedResidueIndex - 1];
              const expQ = experimentalData?.experimentalQ3?.[selectedResidueIndex - 1];
              const isMatch = expQ ? res.q3 === expQ : null;
              return (
                <div className="flex items-center gap-3 text-[11px] font-mono">
                  <span className="font-bold text-sky-400">
                    {res.aminoAcid}{res.index} ({res.name})
                  </span>
                  <span>
                    Pred:{' '}
                    <strong className={res.q3 === 'H' ? 'text-rose-400' : res.q3 === 'E' ? 'text-amber-400' : 'text-cyan-400'}>
                      {res.q3}
                    </strong>
                  </span>
                  {expQ && (
                    <span>
                      Exp: <strong className="text-emerald-400">{expQ}</strong>
                    </span>
                  )}
                  {isMatch !== null && (
                    <span className={isMatch ? 'text-emerald-400 font-semibold' : 'text-rose-400 font-semibold'}>
                      {isMatch ? '✓ Agreement' : '✗ Discrepancy'}
                    </span>
                  )}
                  <span>
                    Conf: <strong className="text-slate-200">{(res.confidence * 100).toFixed(0)}%</strong>
                  </span>
                  <button
                    onClick={() => onSelectResidue(null)}
                    className="text-slate-500 hover:text-slate-300 text-xs px-1"
                  >
                    ✕
                  </button>
                </div>
              );
            })()}
          </div>
        )}
      </div>
    </div>
  );
};
