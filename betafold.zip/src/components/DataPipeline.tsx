import React, { useState } from 'react';
import { Database, Filter, Grid3X3, FileCode, CheckCircle2, ArrowRight, Download } from 'lucide-react';

export const DataPipeline: React.FC = () => {
  const [selectedPipelineStep, setSelectedPipelineStep] = useState<number>(3);

  const pipelineSteps = [
    {
      step: 1,
      name: 'PDB & UniProt Ingestion',
      icon: Database,
      tool: 'BioPython SeqIO & RCSB REST API',
      summary: 'Automated retrieval of ~18,000 crystallized protein structures with resolution < 2.5Å.',
      details: 'Curated high-resolution X-ray diffraction structures from the Protein Data Bank (PDB). Retained single and multi-chain biological assemblies, excluding structures with missing backbone C-alpha coordinates or excessive crystallographic disorder.',
      code: `from Bio import SeqIO
from Bio.PDB import PDBList, PDBParser

# Download non-redundant PDB structures
pdbl = PDBList()
pdbl.download_pdb_files(pdb_codes, pdir="./raw_pdb")

# Extract primary FASTA sequences and DSSP secondary structure labels
parser = PDBParser(QUIET=True)
structure = parser.get_structure("1CRN", "./raw_pdb/1crn.pdb")`
    },
    {
      step: 2,
      name: 'Redundancy Filter & Cleaning',
      icon: Filter,
      tool: 'CD-HIT (25% Cutoff) & Pandas',
      summary: 'Clustered homologous chains at 25% sequence identity to prevent data leakage between train and test splits.',
      details: 'Filtered non-canonical amino acids (U, O, X, B, Z). Applied CD-HIT clustering with a strict 25% pairwise sequence identity threshold. This ensures the benchmark evaluation on CB513 reflects genuine generalization rather than memorized homologous folds.',
      code: `import pandas as pd
import subprocess

# Run CD-HIT sequence identity clustering at 25% threshold
cmd = "cd-hit -i all_proteins.fasta -o nr25_proteins.fasta -c 0.25 -n 2"
subprocess.run(cmd, shell=True)

# Parse clean tabular representation with Pandas
df = pd.DataFrame(records, columns=["pdb_id", "chain", "sequence", "dssp_q3", "resolution"])
df = df[df["sequence"].str.match("^[ACDEFGHIKLMNPQRSTVWY]+$")]
df.to_parquet("curated_training_set.parquet")`
    },
    {
      step: 3,
      name: 'PSSM Feature Matrix Generation',
      icon: Grid3X3,
      tool: 'PSI-BLAST against UniRef90',
      summary: 'Transformed each 1D sequence into a (Length × 20) evolutionary profile matrix.',
      details: 'Executed 3 iterations of PSI-BLAST against the UniRef90 non-redundant database (E-value threshold 0.001). Generated Position-Specific Scoring Matrices (PSSM) where each matrix row represents the log-odds likelihood of 20 amino acid substitutions at that exact residue position.',
      code: `from Bio.Blast.Applications import NcbipsiblastCommandline

# Run 3-iteration PSI-BLAST against UniRef90
psi_cline = NcbipsiblastCommandline(
    cmd="psiblast",
    query="query.fasta",
    db="uniref90.fasta",
    num_iterations=3,
    evalue=0.001,
    out_ascii_pssm="query.pssm"
)
stdout, stderr = psi_cline()

# Parse PSSM into NumPy tensor: shape (L, 20)
# Scaled via standard sigmoid normalization: 1 / (1 + exp(-x))`
    },
    {
      step: 4,
      name: 'Physicochemical Descriptors',
      icon: FileCode,
      tool: 'Bio.SeqUtils.ProtParam & NumPy',
      summary: 'Appended 4 physicochemical properties per residue: Hydrophobicity, Charge, Isoelectric point, Steric bulk.',
      details: 'Enriched the evolutionary PSSM with biophysical attributes. Added Kyte-Doolittle hydropathy values, net electrostatic charge at physiological pH 7.4, steric van der Waals volume, and alpha-helix/beta-sheet propensities, producing the final (L, 44) input tensor.',
      code: `import numpy as np
from Bio.SeqUtils.ProtParam import ProteinAnalysis

# Compute per-residue biophysical descriptors
# Combined tensor: [One-Hot (20) + PSSM (20) + Biophysical (4)] = 44 dimensions
features = np.concatenate([
    one_hot_matrix,      # (L, 20)
    normalized_pssm,     # (L, 20)
    hydrophobicity_col,  # (L, 1)
    charge_col,          # (L, 1)
    steric_volume_col,   # (L, 1)
    isoelectric_col      # (L, 1)
], axis=-1)`
    }
  ];

  // Sample PSSM mini matrix slice for display
  const sampleAAs = ['A', 'R', 'N', 'D', 'C', 'E', 'Q', 'G', 'H', 'I', 'L', 'K', 'M', 'F', 'P', 'S', 'T', 'W', 'Y', 'V'];
  const sampleResidues = [
    { pos: 1, aa: 'T', scores: [-1, -1, 0, -1, -2, -1, -1, -2, -2, 0, -1, -1, -1, -2, -1, 2, 5, -3, -2, 0] },
    { pos: 2, aa: 'T', scores: [0, -1, 0, -1, -2, -1, -1, -2, -2, -1, -1, -1, -1, -2, -1, 2, 6, -3, -2, 0] },
    { pos: 3, aa: 'C', scores: [-1, -4, -3, -4, 9, -4, -3, -3, -4, -2, -2, -4, -2, -3, -3, -1, -1, -3, -3, -1] },
    { pos: 4, aa: 'C', scores: [-1, -4, -3, -4, 9, -4, -3, -3, -4, -2, -2, -4, -2, -3, -3, -1, -1, -3, -3, -1] },
    { pos: 5, aa: 'P', scores: [-1, -2, -2, -2, -3, -1, -2, -2, -2, -3, -3, -1, -2, -4, 7, -1, -1, -4, -3, -2] },
    { pos: 6, aa: 'S', scores: [1, -1, 1, 0, -1, 0, 0, 0, -1, -2, -3, 0, -1, -2, -1, 4, 1, -3, -2, -2] },
    { pos: 7, aa: 'I', scores: [-1, -3, -3, -3, -1, -3, -3, -4, -3, 4, 2, -3, 1, 0, -3, -2, -1, -3, -1, 3] },
    { pos: 8, aa: 'V', scores: [0, -3, -3, -3, -1, -2, -2, -3, -3, 3, 1, -2, 1, -1, -2, -2, 0, -3, -1, 4] },
  ];

  const currentStep = pipelineSteps[selectedPipelineStep - 1];

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-6 shadow-xl">
        <div className="flex flex-wrap items-center justify-between gap-4 pb-5 border-b border-slate-800">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-semibold uppercase tracking-wider">
                BioPython & Pandas Data Pipeline
              </span>
              <span className="px-2.5 py-0.5 rounded-full bg-indigo-500/10 border border-indigo-500/30 text-indigo-400 text-xs font-semibold">
                Feature Engineering
              </span>
            </div>
            <h2 className="text-xl font-bold text-slate-100">
              Protein Sequence & Evolutionary Matrix Preprocessing
            </h2>
            <p className="text-sm text-slate-400 mt-1 max-w-3xl">
              End-to-end data transformation pipeline converting raw FASTA sequences and PDB structural files into rich numerical feature matrices for deep neural network ingestion.
            </p>
          </div>

          <div className="flex items-center gap-2 bg-slate-800/80 px-4 py-2.5 rounded-xl border border-slate-700/60">
            <span className="text-xs text-slate-400">Total Pipeline Dimension:</span>
            <span className="text-sm font-bold font-mono text-indigo-400">(Length, 44 Features)</span>
          </div>
        </div>

        {/* Interactive Step Ribbon */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 mt-6">
          {pipelineSteps.map((s) => {
            const isSelected = selectedPipelineStep === s.step;
            const Icon = s.icon;
            return (
              <button
                key={s.step}
                onClick={() => setSelectedPipelineStep(s.step)}
                className={`p-4 rounded-xl border text-left transition-all group ${
                  isSelected
                    ? 'bg-indigo-950/40 border-indigo-500 ring-2 ring-indigo-500/30 shadow-lg'
                    : 'bg-slate-850/60 border-slate-800 hover:border-slate-700 hover:bg-slate-800/60'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-indigo-400">Phase 0{s.step}</span>
                  <div className={`p-1.5 rounded-lg ${isSelected ? 'bg-indigo-500 text-white' : 'bg-slate-800 text-slate-400'}`}>
                    <Icon className="w-3.5 h-3.5" />
                  </div>
                </div>
                <div className="font-semibold text-slate-200 text-xs group-hover:text-white mb-1">
                  {s.name}
                </div>
                <div className="text-[11px] text-slate-400 line-clamp-2">
                  {s.summary}
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Detail Section: Step breakdown & Python Code */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-5 bg-slate-900/90 rounded-2xl border border-slate-800 p-6 shadow-xl flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="px-2.5 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 font-mono text-xs font-semibold">
                Phase {currentStep.step} Details
              </span>
              <span className="text-xs text-slate-500 font-medium">| {currentStep.tool}</span>
            </div>
            <h3 className="text-lg font-bold text-slate-100">{currentStep.name}</h3>
            <p className="text-sm text-slate-300 mt-3 leading-relaxed">
              {currentStep.details}
            </p>

            <div className="mt-5 p-4 rounded-xl bg-slate-950 border border-slate-800 text-xs space-y-2">
              <div className="text-slate-400 font-semibold flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                Key Deliverables in Major Project:
              </div>
              <ul className="list-disc list-inside text-slate-400 space-y-1 pl-1 text-[11px]">
                <li>Deterministic train/validation/blind-test isolation (zero data leakage)</li>
                <li>Eliminated sequence bias with CD-HIT redundancy clustering</li>
                <li>Log-odds matrix normalization via sigmoid transformation</li>
              </ul>
            </div>
          </div>
        </div>

        <div className="lg:col-span-7 bg-slate-900/90 rounded-2xl border border-slate-800 p-6 shadow-xl flex flex-col">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
            <span className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
              <FileCode className="w-4 h-4 text-emerald-400" />
              BioPython & Pandas Pipeline Implementation
            </span>
            <span className="text-[11px] font-mono text-slate-500">pipeline.py</span>
          </div>

          <pre className="flex-1 bg-slate-950 p-4 rounded-xl border border-slate-800/80 font-mono text-xs text-emerald-300/90 overflow-x-auto leading-relaxed">
            <code>{currentStep.code}</code>
          </pre>
        </div>
      </div>

      {/* Interactive PSSM Heatmap Table */}
      <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-6 shadow-xl">
        <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-800 mb-4">
          <div>
            <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
              <Grid3X3 className="w-4 h-4 text-indigo-400" />
              Interactive Position-Specific Scoring Matrix (PSSM)
            </h3>
            <p className="text-xs text-slate-400">
              Sample log-odds substitution weights generated by PSI-BLAST for Crambin (1CRN)
            </p>
          </div>
          <div className="flex items-center gap-2 text-xs text-slate-400">
            <span className="w-3 h-3 rounded bg-indigo-600 inline-block" />
            <span>Positive: Conserved substitution</span>
            <span className="w-3 h-3 rounded bg-slate-800 inline-block ml-2" />
            <span>Negative: Penalized substitution</span>
          </div>
        </div>

        <div className="overflow-x-auto rounded-xl border border-slate-800 custom-scrollbar">
          <table className="w-full text-center text-xs font-mono">
            <thead className="bg-slate-950 text-slate-400 border-b border-slate-800">
              <tr>
                <th className="py-2.5 px-3 text-left">Pos</th>
                <th className="py-2.5 px-3 text-left">AA</th>
                {sampleAAs.map((aa) => (
                  <th key={aa} className="py-2.5 px-2">{aa}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80 bg-slate-900/40">
              {sampleResidues.map((res) => (
                <tr key={res.pos} className="hover:bg-slate-800/50 transition-colors">
                  <td className="py-2 px-3 text-left font-semibold text-slate-400">{res.pos}</td>
                  <td className="py-2 px-3 text-left font-bold text-sky-400">{res.aa}</td>
                  {res.scores.map((score, sIdx) => {
                    const isPositive = score > 0;
                    const isNeutral = score === 0;
                    return (
                      <td
                        key={sIdx}
                        className={`py-2 px-2 text-[11px] ${
                          score >= 4
                            ? 'bg-indigo-600/60 text-white font-bold'
                            : score > 0
                            ? 'bg-indigo-900/40 text-indigo-200'
                            : isNeutral
                            ? 'text-slate-500'
                            : 'text-slate-600'
                        }`}
                      >
                        {score > 0 ? `+${score}` : score}
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
