import React, { useState } from 'react';
import { BENCHMARK_COMPARISONS, TRAINING_EPOCHS_DATA } from '../data/benchmarkData';
import { BarChart3, TrendingUp, Award, CheckCircle2, Sliders, Table, Activity } from 'lucide-react';

export const BenchmarkEvaluation: React.FC = () => {
  const [activeMetric, setActiveMetric] = useState<'q3' | 'sov' | 'q8'>('q3');

  // CB513 Confusion Matrix Data (Normalized percentages and sample residue counts)
  // Rows: True Class (H, E, C); Columns: Predicted Class (H, E, C)
  const confusionMatrix = {
    classes: ['Helix (H)', 'Strand (E)', 'Coil (C)'],
    matrix: [
      [87.4, 2.1, 10.5], // True H -> Pred H, E, C
      [2.8, 83.6, 13.6], // True E -> Pred H, E, C
      [8.9, 6.7, 84.4],  // True C -> Pred H, E, C
    ],
    counts: [
      [24180, 581, 2905],
      [422, 12610, 2051],
      [2810, 2115, 26640],
    ],
  };

  return (
    <div className="space-y-6">
      {/* Benchmark Summary Header */}
      <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-6 shadow-xl">
        <div className="flex flex-wrap items-center justify-between gap-4 pb-5 border-b border-slate-800">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-semibold uppercase tracking-wider">
                Standard CB513 Benchmark Evaluation
              </span>
              <span className="px-2.5 py-0.5 rounded-full bg-sky-500/10 border border-sky-500/30 text-sky-400 text-xs font-semibold">
                513 Non-Homologous Chains
              </span>
            </div>
            <h2 className="text-xl font-bold text-slate-100">
              Model Performance & Benchmark Validation
            </h2>
            <p className="text-sm text-slate-400 mt-1 max-w-3xl">
              Evaluated on the widely recognized CB513 benchmark and CullPDB test splits. Our hybrid CNN-BiLSTM architecture outperforms baseline LSTM-only and CNN-only models across Q3, Q8, and SOV metrics.
            </p>
          </div>

          {/* Core Metrics Ribbon */}
          <div className="flex items-center gap-3">
            <div className="bg-emerald-950/40 px-4 py-3 rounded-xl border border-emerald-500/30 text-right">
              <div className="text-[11px] text-emerald-300 font-medium">CB513 Q3 Accuracy</div>
              <div className="text-2xl font-black font-mono text-emerald-400">84.8%</div>
            </div>
            <div className="bg-sky-950/40 px-4 py-3 rounded-xl border border-sky-500/30 text-right">
              <div className="text-[11px] text-sky-300 font-medium">SOV Score</div>
              <div className="text-2xl font-black font-mono text-sky-400">81.4%</div>
            </div>
            <div className="bg-indigo-950/40 px-4 py-3 rounded-xl border border-indigo-500/30 text-right">
              <div className="text-[11px] text-indigo-300 font-medium">Q8 Accuracy</div>
              <div className="text-2xl font-black font-mono text-indigo-400">73.6%</div>
            </div>
          </div>
        </div>

        {/* Model Comparison Table */}
        <div className="mt-6">
          <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3 flex items-center justify-between">
            <span>Ablation Study & Model Benchmark Comparison</span>
            <span className="text-[11px] text-slate-500 normal-case font-normal">Higher Q3 / SOV is better</span>
          </h3>
          <div className="overflow-x-auto rounded-xl border border-slate-800">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-950 text-slate-400 font-medium border-b border-slate-800">
                <tr>
                  <th className="py-3 px-4">Architecture</th>
                  <th className="py-3 px-4">Q3 Acc (%)</th>
                  <th className="py-3 px-4">Q8 Acc (%)</th>
                  <th className="py-3 px-4">SOV Score (%)</th>
                  <th className="py-3 px-4">Helix F1</th>
                  <th className="py-3 px-4">Sheet F1</th>
                  <th className="py-3 px-4">Coil F1</th>
                  <th className="py-3 px-4">Epoch Time</th>
                  <th className="py-3 px-4">Params</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/80 bg-slate-900/40">
                {BENCHMARK_COMPARISONS.map((m, idx) => {
                  const isTop = idx === 0;
                  return (
                    <tr
                      key={m.modelName}
                      className={`transition-colors ${
                        isTop ? 'bg-indigo-950/30 font-semibold text-indigo-200' : 'text-slate-300 hover:bg-slate-800/40'
                      }`}
                    >
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-2">
                          {isTop && <Award className="w-4 h-4 text-amber-400 shrink-0" />}
                          <div>
                            <div>{m.modelName}</div>
                            <div className="text-[10px] text-slate-500 font-normal">{m.architectureType}</div>
                          </div>
                        </div>
                      </td>
                      <td className="py-3 px-4 font-mono font-bold text-emerald-400">{m.q3Accuracy}%</td>
                      <td className="py-3 px-4 font-mono text-slate-200">{m.q8Accuracy}%</td>
                      <td className="py-3 px-4 font-mono font-bold text-sky-400">{m.sovScore}%</td>
                      <td className="py-3 px-4 font-mono text-slate-300">{m.helixF1}%</td>
                      <td className="py-3 px-4 font-mono text-slate-300">{m.sheetF1}%</td>
                      <td className="py-3 px-4 font-mono text-slate-300">{m.coilF1}%</td>
                      <td className="py-3 px-4 font-mono text-slate-400">{m.trainingTimePerEpoch}</td>
                      <td className="py-3 px-4 font-mono text-slate-400">{m.paramCount}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Two Columns: Confusion Matrix & Training Epoch Curves */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Confusion Matrix */}
        <div className="lg:col-span-6 bg-slate-900/90 rounded-2xl border border-slate-800 p-6 shadow-xl">
          <div className="flex items-center justify-between pb-4 border-b border-slate-800 mb-4">
            <div>
              <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
                <Table className="w-4 h-4 text-indigo-400" />
                Normalized Confusion Matrix (Q3 Classes)
              </h3>
              <p className="text-xs text-slate-400">
                Diagonal values indicate correct classifications per structural conformation
              </p>
            </div>
            <span className="text-xs font-mono text-slate-500">N = 74,279 residues</span>
          </div>

          {/* Matrix Grid */}
          <div className="mt-4">
            <div className="grid grid-cols-4 gap-2 text-center text-xs">
              {/* Header Corner */}
              <div className="p-2 text-slate-500 font-semibold text-[11px] flex items-center justify-center">
                True \ Pred
              </div>
              <div className="p-2 bg-rose-950/40 text-rose-300 font-bold rounded-lg border border-rose-900/40">
                Helix (H)
              </div>
              <div className="p-2 bg-amber-950/40 text-amber-300 font-bold rounded-lg border border-amber-900/40">
                Strand (E)
              </div>
              <div className="p-2 bg-cyan-950/40 text-cyan-300 font-bold rounded-lg border border-cyan-900/40">
                Coil (C)
              </div>

              {/* Rows */}
              {confusionMatrix.classes.map((clsName, rowIdx) => (
                <React.Fragment key={`row-${clsName}`}>
                  <div className="p-2 bg-slate-950 text-slate-300 font-medium rounded-lg text-left flex items-center">
                    {clsName}
                  </div>
                  {confusionMatrix.matrix[rowIdx].map((pct, colIdx) => {
                    const isDiagonal = rowIdx === colIdx;
                    const count = confusionMatrix.counts[rowIdx][colIdx];
                    return (
                      <div
                        key={`cell-${rowIdx}-${colIdx}`}
                        className={`p-3 rounded-lg border flex flex-col items-center justify-center transition-all ${
                          isDiagonal
                            ? 'bg-emerald-950/50 border-emerald-500/50 text-emerald-300 font-bold shadow-sm'
                            : 'bg-slate-950/60 border-slate-800/80 text-slate-400'
                        }`}
                      >
                        <span className="text-sm font-mono">{pct}%</span>
                        <span className="text-[10px] text-slate-500 font-mono">({count.toLocaleString()})</span>
                      </div>
                    );
                  })}
                </React.Fragment>
              ))}
            </div>

            {/* Matrix Insights */}
            <div className="mt-4 p-3.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-400 leading-relaxed">
              <span className="text-slate-200 font-semibold">Key Finding:</span> Helix prediction sensitivity is highest at <span className="text-emerald-400 font-mono font-bold">87.4%</span> due to characteristic i+4 hydrogen bonding motifs. Most minor confusion occurs between Strand (E) and Coil (C) at terminal edges of short antiparallel sheets.
            </div>
          </div>
        </div>

        {/* Right: Training Telemetry & Loss Curves */}
        <div className="lg:col-span-6 bg-slate-900/90 rounded-2xl border border-slate-800 p-6 shadow-xl">
          <div className="flex items-center justify-between pb-4 border-b border-slate-800 mb-4">
            <div>
              <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
                <Activity className="w-4 h-4 text-emerald-400" />
                Training & Validation Convergence (30 Epochs)
              </h3>
              <p className="text-xs text-slate-400">
                Monitored Categorical Cross-Entropy loss and validation Q3 accuracy
              </p>
            </div>
            <span className="text-xs font-mono text-emerald-400 font-semibold">Loss: 0.392</span>
          </div>

          {/* Epoch Data Progress Visualizer */}
          <div className="space-y-3">
            {TRAINING_EPOCHS_DATA.map((epoch) => (
              <div key={epoch.epoch} className="p-3 rounded-xl bg-slate-950 border border-slate-800/80">
                <div className="flex items-center justify-between text-xs mb-1.5">
                  <span className="font-semibold text-slate-300 font-mono">Epoch {epoch.epoch}</span>
                  <div className="flex items-center gap-3 font-mono text-[11px]">
                    <span className="text-slate-400">Val Loss: <strong className="text-slate-200">{epoch.valLoss}</strong></span>
                    <span className="text-emerald-400">Val Q3: <strong>{epoch.valQ3}%</strong></span>
                  </div>
                </div>
                {/* Visual Bar representation */}
                <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden flex">
                  <div
                    style={{ width: `${epoch.valQ3}%` }}
                    className="bg-gradient-to-r from-indigo-500 to-emerald-400 h-full rounded-full transition-all duration-500"
                  />
                </div>
              </div>
            ))}
          </div>

          {/* GPU Training Speedup Note */}
          <div className="mt-4 p-3.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-400 flex items-center justify-between">
            <span className="text-slate-300">GPU Batch Processing Latency:</span>
            <span className="font-mono text-emerald-400 font-bold">4.2 sec / epoch (NVIDIA CUDA)</span>
          </div>
        </div>
      </div>
    </div>
  );
};
