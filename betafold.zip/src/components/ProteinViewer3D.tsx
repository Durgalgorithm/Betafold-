import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { ResiduePrediction, SecondaryStructure3 } from '../types';
import { generateBackbone3DCoordinates } from '../utils/bioinformatics';
import { RotateCw, ZoomIn, ZoomOut, Eye, Sparkles, Layers, RefreshCw } from 'lucide-react';

interface ProteinViewer3DProps {
  residues: ResiduePrediction[];
  selectedResidueIndex: number | null;
  onSelectResidue: (index: number | null) => void;
  proteinName: string;
}

export const ProteinViewer3D: React.FC<ProteinViewer3DProps> = ({
  residues,
  selectedResidueIndex,
  onSelectResidue,
  proteinName,
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const [colorMode, setColorMode] = useState<'secondary' | 'confidence' | 'hydrophobicity'>('secondary');
  const [renderStyle, setRenderStyle] = useState<'ribbon' | 'trace' | 'atoms'>('ribbon');
  const [autoRotate, setAutoRotate] = useState(true);
  const [hoveredResidue, setHoveredResidue] = useState<ResiduePrediction | null>(null);

  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const groupRef = useRef<THREE.Group | null>(null);
  const isDraggingRef = useRef(false);
  const prevMousePos = useRef({ x: 0, y: 0 });

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    // Scene
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0f172a); // Deep slate neutral dark
    sceneRef.current = scene;

    // Camera
    const camera = new THREE.PerspectiveCamera(
      45,
      container.clientWidth / container.clientHeight,
      0.1,
      1000
    );
    camera.position.set(0, 0, 85);
    cameraRef.current = camera;

    // Renderer
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'high-performance' });
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.1;
    container.innerHTML = '';
    container.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.7);
    scene.add(ambientLight);

    const dirLight1 = new THREE.DirectionalLight(0xffffff, 1.2);
    dirLight1.position.set(50, 60, 50);
    scene.add(dirLight1);

    const dirLight2 = new THREE.DirectionalLight(0x94a3b8, 0.6);
    dirLight2.position.set(-50, -40, -40);
    scene.add(dirLight2);

    const pointLight = new THREE.PointLight(0x38bdf8, 1.0, 150);
    pointLight.position.set(0, 20, 30);
    scene.add(pointLight);

    // Group for protein model
    const proteinGroup = new THREE.Group();
    scene.add(proteinGroup);
    groupRef.current = proteinGroup;

    // Mouse drag handlers
    const handleMouseDown = (e: MouseEvent) => {
      isDraggingRef.current = true;
      prevMousePos.current = { x: e.clientX, y: e.clientY };
    };

    const handleMouseMove = (e: MouseEvent) => {
      if (!isDraggingRef.current || !groupRef.current) return;
      const deltaX = e.clientX - prevMousePos.current.x;
      const deltaY = e.clientY - prevMousePos.current.y;
      groupRef.current.rotation.y += deltaX * 0.008;
      groupRef.current.rotation.x += deltaY * 0.008;
      prevMousePos.current = { x: e.clientX, y: e.clientY };
    };

    const handleMouseUp = () => {
      isDraggingRef.current = false;
    };

    const handleWheel = (e: WheelEvent) => {
      e.preventDefault();
      if (!cameraRef.current) return;
      const zoomSpeed = 0.05;
      cameraRef.current.position.z = Math.max(
        20,
        Math.min(180, cameraRef.current.position.z + e.deltaY * zoomSpeed)
      );
    };

    container.addEventListener('mousedown', handleMouseDown);
    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleMouseUp);
    container.addEventListener('wheel', handleWheel, { passive: false });

    // Animation Loop
    let animationFrameId: number;
    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);
      if (autoRotate && groupRef.current && !isDraggingRef.current) {
        groupRef.current.rotation.y += 0.004;
      }
      renderer.render(scene, camera);
    };
    animate();

    // Resize Observer
    const resizeObserver = new ResizeObserver(() => {
      if (!container || !rendererRef.current || !cameraRef.current) return;
      const width = container.clientWidth;
      const height = container.clientHeight;
      cameraRef.current.aspect = width / height;
      cameraRef.current.updateProjectionMatrix();
      rendererRef.current.setSize(width, height);
    });
    resizeObserver.observe(container);

    return () => {
      cancelAnimationFrame(animationFrameId);
      resizeObserver.disconnect();
      container.removeEventListener('mousedown', handleMouseDown);
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
      container.removeEventListener('wheel', handleWheel);
      renderer.dispose();
      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
    };
  }, [autoRotate]);

  // Rebuild 3D protein mesh when residues, colorMode, or renderStyle change
  useEffect(() => {
    if (!groupRef.current || residues.length === 0) return;

    const group = groupRef.current;
    while (group.children.length > 0) {
      const obj = group.children[0];
      group.remove(obj);
      if (obj instanceof THREE.Mesh) {
        obj.geometry.dispose();
        if (Array.isArray(obj.material)) obj.material.forEach((m) => m.dispose());
        else obj.material.dispose();
      }
    }

    const { points } = generateBackbone3DCoordinates(residues);
    if (points.length < 2) return;

    const getColor = (res: ResiduePrediction): THREE.Color => {
      if (colorMode === 'secondary') {
        if (res.q3 === 'H') return new THREE.Color(0xf43f5e); // Ruby Crimson Alpha Helix
        if (res.q3 === 'E') return new THREE.Color(0xf59e0b); // Amber Golden Beta Strand
        return new THREE.Color(0x06b6d4); // Cyan Coil
      } else if (colorMode === 'confidence') {
        // High confidence green, medium yellow, low orange/red
        const c = res.confidence;
        if (c >= 0.85) return new THREE.Color(0x10b981);
        if (c >= 0.65) return new THREE.Color(0xfbbf24);
        return new THREE.Color(0xef4444);
      } else {
        // Hydrophobicity: blue (hydrophilic) -> white -> orange/red (hydrophobic)
        const h = res.hydrophobicity; // -4.5 to +4.5
        const norm = (h + 4.5) / 9.0;
        return new THREE.Color().setHSL(0.65 - norm * 0.65, 0.85, 0.5);
      }
    };

    if (renderStyle === 'ribbon') {
      // 3D Cartoon / Ribbon representation
      // We partition sequence into continuous secondary structure segments
      for (let i = 0; i < points.length - 1; i++) {
        const p1 = points[i];
        const p2 = points[i + 1];
        const res = residues[i];
        const color = getColor(res);

        const v1 = new THREE.Vector3(p1.x, p1.y, p1.z);
        const v2 = new THREE.Vector3(p2.x, p2.y, p2.z);
        const dir = new THREE.Vector3().subVectors(v2, v1);
        const len = dir.length();
        const mid = new THREE.Vector3().addVectors(v1, v2).multiplyScalar(0.5);

        let geom: THREE.BufferGeometry;

        if (res.q3 === 'H') {
          // Helical ribbon cylinder/toroid segment
          geom = new THREE.CylinderGeometry(1.6, 1.6, len, 16);
        } else if (res.q3 === 'E') {
          // Beta-strand flat ribbon
          geom = new THREE.BoxGeometry(2.4, len, 0.6);
        } else {
          // Smooth coil tube
          geom = new THREE.CylinderGeometry(0.7, 0.7, len, 12);
        }

        const isSelected = selectedResidueIndex === res.index;
        const mat = new THREE.MeshStandardMaterial({
          color: isSelected ? 0xffffff : color,
          roughness: 0.3,
          metalness: 0.15,
          emissive: isSelected ? 0x38bdf8 : 0x000000,
          emissiveIntensity: isSelected ? 0.6 : 0,
        });

        const mesh = new THREE.Mesh(geom, mat);
        mesh.position.copy(mid);
        mesh.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir.clone().normalize());
        mesh.userData = { residue: res };
        group.add(mesh);
      }

      // Add C-alpha joint spheres
      points.forEach((p, idx) => {
        const res = residues[idx];
        const color = getColor(res);
        const isSelected = selectedResidueIndex === res.index;
        const sphereGeom = new THREE.SphereGeometry(res.q3 === 'H' ? 1.6 : res.q3 === 'E' ? 1.2 : 0.8, 12, 12);
        const sphereMat = new THREE.MeshStandardMaterial({
          color: isSelected ? 0xffffff : color,
          roughness: 0.25,
          metalness: 0.2,
          emissive: isSelected ? 0x38bdf8 : 0x000000,
          emissiveIntensity: isSelected ? 0.8 : 0,
        });
        const sphere = new THREE.Mesh(sphereGeom, sphereMat);
        sphere.position.set(p.x, p.y, p.z);
        sphere.userData = { residue: res };
        group.add(sphere);
      });
    } else if (renderStyle === 'trace') {
      // Backbone line trace
      const curvePoints = points.map((p) => new THREE.Vector3(p.x, p.y, p.z));
      const curve = new THREE.CatmullRomCurve3(curvePoints);
      const tubeGeom = new THREE.TubeGeometry(curve, points.length * 4, 0.9, 12, false);

      // Vertex coloring along curve
      const count = tubeGeom.attributes.position.count;
      const colors = new Float32Array(count * 3);
      for (let i = 0; i < count; i++) {
        const progress = Math.min(1, Math.max(0, i / count));
        const resIdx = Math.min(residues.length - 1, Math.floor(progress * residues.length));
        const c = getColor(residues[resIdx]);
        colors[i * 3] = c.r;
        colors[i * 3 + 1] = c.g;
        colors[i * 3 + 2] = c.b;
      }
      tubeGeom.setAttribute('color', new THREE.BufferAttribute(colors, 3));

      const tubeMat = new THREE.MeshStandardMaterial({
        vertexColors: true,
        roughness: 0.35,
        metalness: 0.1,
      });
      const tubeMesh = new THREE.Mesh(tubeGeom, tubeMat);
      group.add(tubeMesh);
    } else {
      // Atoms / Spacefill mode
      points.forEach((p, idx) => {
        const res = residues[idx];
        const color = getColor(res);
        const isSelected = selectedResidueIndex === res.index;
        const sphereGeom = new THREE.SphereGeometry(1.9, 16, 16);
        const sphereMat = new THREE.MeshStandardMaterial({
          color: isSelected ? 0xffffff : color,
          roughness: 0.3,
          metalness: 0.1,
          emissive: isSelected ? 0x38bdf8 : 0x000000,
          emissiveIntensity: isSelected ? 0.7 : 0,
        });
        const sphere = new THREE.Mesh(sphereGeom, sphereMat);
        sphere.position.set(p.x, p.y, p.z);
        sphere.userData = { residue: res };
        group.add(sphere);
      });
    }
  }, [residues, colorMode, renderStyle, selectedResidueIndex]);

  const handleResetView = () => {
    if (cameraRef.current && groupRef.current) {
      cameraRef.current.position.set(0, 0, 85);
      groupRef.current.rotation.set(0, 0, 0);
    }
  };

  const handleZoom = (direction: 'in' | 'out') => {
    if (cameraRef.current) {
      const factor = direction === 'in' ? -15 : 15;
      cameraRef.current.position.z = Math.max(20, Math.min(180, cameraRef.current.position.z + factor));
    }
  };

  return (
    <div id="protein-viewer-container" className="relative w-full h-full min-h-[460px] bg-slate-950 rounded-2xl overflow-hidden border border-slate-800 shadow-2xl flex flex-col">
      {/* Viewer Header Overlay */}
      <div className="absolute top-4 left-4 z-10 flex items-center gap-3">
        <div className="bg-slate-900/90 backdrop-blur-md px-3.5 py-1.5 rounded-xl border border-slate-700/60 shadow-lg flex items-center gap-2">
          <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
          <span className="text-xs font-semibold text-slate-200 tracking-wide">3D Cartoon Secondary Structure</span>
          <span className="text-[11px] font-mono text-slate-400">| {proteinName}</span>
        </div>
      </div>

      {/* Controls Overlay Top Right */}
      <div className="absolute top-4 right-4 z-10 flex flex-wrap items-center gap-2 bg-slate-900/90 backdrop-blur-md p-1.5 rounded-xl border border-slate-700/60 shadow-lg">
        {/* Color Mode Switcher */}
        <div className="flex items-center bg-slate-800/80 rounded-lg p-0.5 text-xs">
          <button
            id="color-mode-secondary"
            onClick={() => setColorMode('secondary')}
            className={`px-2.5 py-1 rounded-md transition-all ${
              colorMode === 'secondary'
                ? 'bg-rose-500/20 text-rose-300 font-medium'
                : 'text-slate-400 hover:text-slate-200'
            }`}
            title="Color by Secondary Structure (Helix, Sheet, Coil)"
          >
            Secondary
          </button>
          <button
            id="color-mode-confidence"
            onClick={() => setColorMode('confidence')}
            className={`px-2.5 py-1 rounded-md transition-all ${
              colorMode === 'confidence'
                ? 'bg-emerald-500/20 text-emerald-300 font-medium'
                : 'text-slate-400 hover:text-slate-200'
            }`}
            title="Color by Neural Confidence Score"
          >
            Confidence
          </button>
          <button
            id="color-mode-hydrophobicity"
            onClick={() => setColorMode('hydrophobicity')}
            className={`px-2.5 py-1 rounded-md transition-all ${
              colorMode === 'hydrophobicity'
                ? 'bg-sky-500/20 text-sky-300 font-medium'
                : 'text-slate-400 hover:text-slate-200'
            }`}
            title="Color by Kyte-Doolittle Hydrophobicity"
          >
            Hydrophobic
          </button>
        </div>

        {/* Render Style */}
        <div className="flex items-center bg-slate-800/80 rounded-lg p-0.5 text-xs">
          <button
            id="render-style-ribbon"
            onClick={() => setRenderStyle('ribbon')}
            className={`px-2 py-1 rounded-md transition-all ${
              renderStyle === 'ribbon' ? 'bg-indigo-600 text-white font-medium' : 'text-slate-400 hover:text-slate-200'
            }`}
            title="Cartoon Ribbon (Helices as cylinders, Sheets as arrows)"
          >
            Ribbon
          </button>
          <button
            id="render-style-trace"
            onClick={() => setRenderStyle('trace')}
            className={`px-2 py-1 rounded-md transition-all ${
              renderStyle === 'trace' ? 'bg-indigo-600 text-white font-medium' : 'text-slate-400 hover:text-slate-200'
            }`}
            title="C-alpha Continuous Tube Trace"
          >
            Tube
          </button>
          <button
            id="render-style-atoms"
            onClick={() => setRenderStyle('atoms')}
            className={`px-2 py-1 rounded-md transition-all ${
              renderStyle === 'atoms' ? 'bg-indigo-600 text-white font-medium' : 'text-slate-400 hover:text-slate-200'
            }`}
            title="Residue Sphere Nodes"
          >
            Nodes
          </button>
        </div>

        {/* View Tools */}
        <div className="flex items-center gap-1 pl-1 border-l border-slate-700/60">
          <button
            id="toggle-autorotate-btn"
            onClick={() => setAutoRotate(!autoRotate)}
            className={`p-1.5 rounded-lg border transition-all ${
              autoRotate
                ? 'bg-sky-500/20 text-sky-400 border-sky-500/30'
                : 'bg-slate-800 text-slate-400 border-slate-700 hover:text-slate-200'
            }`}
            title={autoRotate ? 'Pause Rotation' : 'Auto Rotate'}
          >
            <RotateCw className={`w-3.5 h-3.5 ${autoRotate ? 'animate-spin' : ''}`} />
          </button>
          <button
            id="zoom-in-btn"
            onClick={() => handleZoom('in')}
            className="p-1.5 rounded-lg bg-slate-800 text-slate-400 border border-slate-700 hover:text-slate-200 transition-all"
            title="Zoom In"
          >
            <ZoomIn className="w-3.5 h-3.5" />
          </button>
          <button
            id="zoom-out-btn"
            onClick={() => handleZoom('out')}
            className="p-1.5 rounded-lg bg-slate-800 text-slate-400 border border-slate-700 hover:text-slate-200 transition-all"
            title="Zoom Out"
          >
            <ZoomOut className="w-3.5 h-3.5" />
          </button>
          <button
            id="reset-view-btn"
            onClick={handleResetView}
            className="p-1.5 rounded-lg bg-slate-800 text-slate-400 border border-slate-700 hover:text-slate-200 transition-all"
            title="Reset Orientation"
          >
            <RefreshCw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* 3D Canvas Mount */}
      <div
        ref={mountRef}
        className="w-full flex-1 cursor-grab active:cursor-grabbing select-none"
      />

      {/* Color Legend Bottom Left */}
      <div className="absolute bottom-4 left-4 z-10 bg-slate-900/90 backdrop-blur-md px-3.5 py-2.5 rounded-xl border border-slate-800 shadow-xl flex items-center gap-4 text-xs">
        {colorMode === 'secondary' ? (
          <>
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-full bg-rose-500 shadow-sm shadow-rose-500/50" />
              <span className="text-slate-300 font-medium">Alpha Helix (H)</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-full bg-amber-500 shadow-sm shadow-amber-500/50" />
              <span className="text-slate-300 font-medium">Beta Strand (E)</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-full bg-cyan-400 shadow-sm shadow-cyan-400/50" />
              <span className="text-slate-300 font-medium">Random Coil (C)</span>
            </div>
          </>
        ) : colorMode === 'confidence' ? (
          <>
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-full bg-emerald-500" />
              <span className="text-slate-300 font-medium">&gt; 85% High</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-full bg-amber-400" />
              <span className="text-slate-300 font-medium">65 - 85% Moderate</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-full bg-rose-500" />
              <span className="text-slate-300 font-medium">&lt; 65% Low</span>
            </div>
          </>
        ) : (
          <>
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-full bg-rose-500" />
              <span className="text-slate-300 font-medium">Hydrophobic (Buried)</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-full bg-sky-500" />
              <span className="text-slate-300 font-medium">Hydrophilic (Exposed)</span>
            </div>
          </>
        )}
      </div>

      {/* Active / Hovered Residue Card Bottom Right */}
      {selectedResidueIndex !== null && residues[selectedResidueIndex - 1] && (
        <div className="absolute bottom-4 right-4 z-10 bg-slate-900/95 backdrop-blur-md p-3.5 rounded-xl border border-sky-500/40 shadow-2xl text-xs max-w-xs animate-in fade-in slide-in-from-bottom-2">
          {(() => {
            const res = residues[selectedResidueIndex - 1];
            return (
              <div>
                <div className="flex items-center justify-between gap-3 mb-1.5 border-b border-slate-800 pb-1.5">
                  <div className="flex items-center gap-1.5">
                    <span className="font-mono font-bold text-sm text-sky-400">
                      {res.aminoAcid}{res.index}
                    </span>
                    <span className="text-slate-300 font-medium">({res.name})</span>
                  </div>
                  <button
                    onClick={() => onSelectResidue(null)}
                    className="text-slate-500 hover:text-slate-300 text-xs px-1"
                  >
                    ✕
                  </button>
                </div>
                <div className="grid grid-cols-2 gap-x-3 gap-y-1 text-[11px] text-slate-400">
                  <div>
                    Predicted Q3:{' '}
                    <span className={`font-semibold ${
                      res.q3 === 'H' ? 'text-rose-400' : res.q3 === 'E' ? 'text-amber-400' : 'text-cyan-400'
                    }`}>
                      {res.q3 === 'H' ? 'Helix (H)' : res.q3 === 'E' ? 'Strand (E)' : 'Coil (C)'}
                    </span>
                  </div>
                  <div>
                    DSSP Q8: <span className="text-slate-200 font-mono font-semibold">{res.q8}</span>
                  </div>
                  <div>
                    Confidence: <span className="text-emerald-400 font-mono font-semibold">{(res.confidence * 100).toFixed(1)}%</span>
                  </div>
                  <div>
                    Solvent: <span className="text-slate-300 font-medium">{res.solventAccessibility}</span>
                  </div>
                  <div>
                    Hydrophobicity: <span className="text-slate-300 font-mono">{res.hydrophobicity.toFixed(1)}</span>
                  </div>
                  <div>
                    PSSM Score: <span className="text-amber-300 font-mono">{res.pssmScore}</span>
                  </div>
                </div>
                {res.groundTruthQ3 && (
                  <div className="mt-1.5 pt-1.5 border-t border-slate-800/80 flex items-center justify-between text-[11px]">
                    <span className="text-slate-400">Ground Truth (DSSP):</span>
                    <span className={`font-mono font-bold ${
                      res.q3 === res.groundTruthQ3 ? 'text-emerald-400' : 'text-rose-400'
                    }`}>
                      {res.groundTruthQ3} {res.q3 === res.groundTruthQ3 ? '✓ Match' : '✗ Mispredict'}
                    </span>
                  </div>
                )}
              </div>
            );
          })()}
        </div>
      )}
    </div>
  );
};
