import React, { useState } from 'react';
import { MODEL_ARCHITECTURE_LAYERS } from '../data/benchmarkData';
import { ArchitectureLayer } from '../types';
import { Cpu, Layers, Zap, Code2, Network, CheckCircle2, Sliders, HardDrive } from 'lucide-react';

export const ModelArchitecture: React.FC = () => {
  const [selectedLayerId, setSelectedLayerId] = useState<string>('layer_2');

  const selectedLayer =
    MODEL_ARCHITECTURE_LAYERS.find((l) => l.id === selectedLayerId) ||
    MODEL_ARCHITECTURE_LAYERS[0];

  const totalParams = MODEL_ARCHITECTURE_LAYERS.reduce((acc, l) => acc + l.params, 0);

  const getCodeSnippet = (layer: ArchitectureLayer) => {
    switch (layer.type) {
      case 'Input':
        return `# Input Feature Fusion Layer (One-Hot 20D + PSSM 20D + Physicochemical 4D)
inputs = tf.keras.Input(shape=(None, 44), name="fused_features_input")`;
      case 'Conv1D':
        return `# Multi-Scale Parallel 1D Convolutions (Oligopeptide Motifs)
conv3 = tf.keras.layers.Conv1D(filters=64, kernel_size=3, padding="same", activation="relu")(x)
conv5 = tf.keras.layers.Conv1D(filters=32, kernel_size=5, padding="same", activation="relu")(x)
conv7 = tf.keras.layers.Conv1D(filters=32, kernel_size=7, padding="same", activation="relu")(x)
x = tf.keras.layers.Concatenate()([conv3, conv5, conv7]) # (Batch, L, 128)`;
      case 'BatchNorm':
        return `# Batch Normalization & Spatial Dropout
x = tf.keras.layers.BatchNormalization(momentum=0.99)(x)
x = tf.keras.layers.SpatialDropout1D(rate=0.25)(x)`;
      case 'BiLSTM':
        return `# Bidirectional LSTM capturing forward & backward sequential context
bilstm = tf.keras.layers.Bidirectional(
    tf.keras.layers.LSTM(units=128, return_sequences=True, recurrent_dropout=0.2)
)(x) # Output shape: (Batch, L, 256)`;
      case 'Attention':
        return `# Multi-Head Self-Attention with Residual Connection
attn_out = tf.keras.layers.MultiHeadAttention(num_heads=4, key_dim=64)(x, x)
x = tf.keras.layers.Add()([x, attn_out])
x = tf.keras.layers.LayerNormalization()(x)`;
      case 'Dense':
        return `# Dense Representation Projection
x = tf.keras.layers.Dense(units=128, activation="swish", kernel_regularizer=tf.keras.regularizers.l2(1e-4))(x)
x = tf.keras.layers.Dropout(0.2)(x)`;
      case 'Output':
        return `# Dual-Task Softmax Heads (Q3 3-state and Q8 8-state)
q3_head = tf.keras.layers.Dense(3, activation="softmax", name="q3_output")(x)
q8_head = tf.keras.layers.Dense(8, activation="softmax", name="q8_output")(x)
model = tf.keras.Model(inputs=inputs, outputs=[q3_head, q8_head], name="Betafold_CNN_BiLSTM")`;
      default:
        return `# Layer configuration: ${layer.name}`;
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Architecture Overview Banner */}
      <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-6 shadow-xl">
        <div className="flex flex-wrap items-center justify-between gap-4 pb-6 border-b border-slate-800">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2.5 py-0.5 rounded-full bg-indigo-500/10 border border-indigo-500/30 text-indigo-400 text-xs font-semibold uppercase tracking-wider">
                TensorFlow 2.16+ Core Model
              </span>
              <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-semibold">
                Mixed Precision FP16
              </span>
            </div>
            <h2 className="text-xl font-bold text-slate-100">
              Hybrid CNN-BiLSTM Neural Architecture
            </h2>
            <p className="text-sm text-slate-400 max-w-3xl mt-1">
              Combines multi-scale 1D Convolutional blocks for local oligopeptide pattern recognition with stacked Bidirectional Long Short-Term Memory (BiLSTM) for long-range sequence context memory.
            </p>
          </div>

          {/* Quick Metrics Badge */}
          <div className="flex items-center gap-3">
            <div className="bg-slate-800/80 px-4 py-2.5 rounded-xl border border-slate-700/60 text-right">
              <div className="text-[11px] text-slate-400 font-medium">Total Parameters</div>
              <div className="text-base font-bold font-mono text-indigo-400">
                {totalParams.toLocaleString()}
              </div>
            </div>
            <div className="bg-slate-800/80 px-4 py-2.5 rounded-xl border border-slate-700/60 text-right">
              <div className="text-[11px] text-slate-400 font-medium">Inference Latency</div>
              <div className="text-base font-bold font-mono text-emerald-400">
                1.2 ms / seq
              </div>
            </div>
          </div>
        </div>

        {/* Interactive Architecture Pipeline Graph */}
        <div className="mt-6">
          <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3">
            Model Layer Flow & Forward Pass (Click any layer to inspect weights and parameters)
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {MODEL_ARCHITECTURE_LAYERS.map((layer, index) => {
              const isSelected = selectedLayerId === layer.id;
              return (
                <button
                  key={layer.id}
                  onClick={() => setSelectedLayerId(layer.id)}
                  className={`relative p-4 rounded-xl border text-left transition-all group ${
                    isSelected
                      ? 'bg-indigo-950/40 border-indigo-500 ring-2 ring-indigo-500/30 shadow-lg'
                      : 'bg-slate-850/60 border-slate-800 hover:border-slate-700 hover:bg-slate-800/60'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[11px] font-mono text-slate-500">
                      Step {index + 1}
                    </span>
                    <span
                      className={`text-[10px] font-semibold px-2 py-0.5 rounded-md ${
                        layer.type === 'Conv1D'
                          ? 'bg-rose-500/20 text-rose-300'
                          : layer.type === 'BiLSTM'
                          ? 'bg-amber-500/20 text-amber-300'
                          : layer.type === 'Attention'
                          ? 'bg-purple-500/20 text-purple-300'
                          : 'bg-sky-500/20 text-sky-300'
                      }`}
                    >
                      {layer.type}
                    </span>
                  </div>
                  <div className="font-semibold text-slate-200 text-sm group-hover:text-white transition-colors">
                    {layer.name}
                  </div>
                  <div className="mt-1 font-mono text-[11px] text-slate-400">
                    Shape: {layer.shape}
                  </div>
                  <div className="mt-1 text-[11px] text-slate-500 font-mono">
                    {layer.params > 0 ? `${layer.params.toLocaleString()} params` : '0 params (Input)'}
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Layer Detail Inspector & Code View */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Layer Specs */}
        <div className="lg:col-span-6 bg-slate-900/90 rounded-2xl border border-slate-800 p-6 shadow-xl flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2.5 mb-2">
              <span className="p-2 rounded-lg bg-indigo-500/20 text-indigo-400">
                <Sliders className="w-4 h-4" />
              </span>
              <div>
                <h3 className="text-base font-bold text-slate-100">{selectedLayer.name}</h3>
                <span className="text-xs font-mono text-indigo-400">Tensor Type: {selectedLayer.type}</span>
              </div>
            </div>

            <p className="text-sm text-slate-300 mt-3 leading-relaxed">
              {selectedLayer.description}
            </p>

            {/* Hyperparameters table */}
            <div className="mt-5">
              <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
                Layer Hyperparameters & Tensor Config
              </h4>
              <div className="bg-slate-950 rounded-xl border border-slate-800 overflow-hidden divide-y divide-slate-800/80">
                {Object.entries(selectedLayer.hyperparameters).map(([key, val]) => (
                  <div key={key} className="flex items-center justify-between px-4 py-2.5 text-xs">
                    <span className="text-slate-400 font-medium">{key.replace(/_/g, ' ')}</span>
                    <span className="font-mono text-slate-200 font-semibold">{String(val)}</span>
                  </div>
                ))}
                <div className="flex items-center justify-between px-4 py-2.5 text-xs bg-slate-900/40">
                  <span className="text-slate-400 font-medium">Trainable Weight Params</span>
                  <span className="font-mono text-emerald-400 font-bold">{selectedLayer.params.toLocaleString()}</span>
                </div>
                <div className="flex items-center justify-between px-4 py-2.5 text-xs bg-slate-900/40">
                  <span className="text-slate-400 font-medium">Output Tensor Shape</span>
                  <span className="font-mono text-sky-400 font-bold">{selectedLayer.shape}</span>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
            <span>Optimization: AdamW (lr=1e-3, weight_decay=1e-4)</span>
            <span className="text-emerald-400 font-medium">Loss: CrossEntropy + SOV-penalized</span>
          </div>
        </div>

        {/* Right: TensorFlow Implementation Snippet */}
        <div className="lg:col-span-6 bg-slate-900/90 rounded-2xl border border-slate-800 p-6 shadow-xl flex flex-col">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
            <div className="flex items-center gap-2">
              <Code2 className="w-4 h-4 text-emerald-400" />
              <span className="text-xs font-semibold text-slate-300">TensorFlow 2.x Python Implementation</span>
            </div>
            <span className="text-[11px] font-mono text-slate-500">model.py</span>
          </div>

          <pre className="flex-1 bg-slate-950 p-4 rounded-xl border border-slate-800/80 font-mono text-xs text-emerald-300/90 overflow-x-auto leading-relaxed">
            <code>{getCodeSnippet(selectedLayer)}</code>
          </pre>

          {/* Training & GPU Optimization Highlights */}
          <div className="mt-4 p-4 rounded-xl bg-slate-950/60 border border-slate-800 text-xs">
            <div className="font-semibold text-slate-300 flex items-center gap-1.5 mb-1.5">
              <Zap className="w-3.5 h-3.5 text-amber-400" />
              <span>Project Senior Benchmark Optimization</span>
            </div>
            <p className="text-slate-400 text-[11px] leading-normal">
              By applying <span className="text-slate-200 font-mono">tf.data.Dataset.bucket_by_sequence_length</span> and mixed-precision <span className="text-slate-200 font-mono">float16</span> on NVIDIA GPU, the training epoch time dropped from 18.4s to 4.2s — an over 4.3× speedup allowing 50 epochs in under 4 minutes.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
