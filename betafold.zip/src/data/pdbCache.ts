import { ExperimentalStructureData } from '../types';
import { generateExperimentalPdbText } from '../utils/bioinformatics';

/**
 * Built-in curated experimental PDB structures for instant zero-latency benchmark comparisons.
 */
export const CURATED_PDB_STRUCTURES: Record<string, Partial<ExperimentalStructureData>> = {
  '1CRN': {
    pdbId: '1CRN',
    title: 'Water Structure of a Hydrophobic Protein at Atomic Resolution (Crambin)',
    method: 'X-RAY DIFFRACTION',
    resolution: '0.54 Å',
    chain: 'A',
    sequence: 'TTCCPSIVARSNFNVCRLPGTPEAICATYTGCIIIPGATCPGDYAN',
    length: 46,
    experimentalQ3: 'EEEECCHHHHHHHHHHHHHCCCHHHHHHHHCEEEECCCCCCCCCCC',
    get pdbText() {
      return generateExperimentalPdbText(this.sequence!, this.experimentalQ3!, 'A');
    }
  },
  '1UBQ': {
    pdbId: '1UBQ',
    title: 'Structure of Human Ubiquitin Refined at 1.8 Å Resolution',
    method: 'X-RAY DIFFRACTION',
    resolution: '1.80 Å',
    chain: 'A',
    sequence: 'MQIFVKTLTGKTITLEVEPSDTIENVKAKIQDKEGIPPDQQRLIFAGKQLEDGRTLSDYNIQKESTLHLVLRLRGG',
    length: 76,
    experimentalQ3: 'EEEEEEECCEEEEEEEECCCCCHHHHHHHHHHHHCCCCCEEEEEECCEEECCCCCHHHHCCCCEEEEEEEEECCCC',
    get pdbText() {
      return generateExperimentalPdbText(this.sequence!, this.experimentalQ3!, 'A');
    }
  },
  '2HBA': {
    pdbId: '2HBA',
    title: 'Deoxy Human Hemoglobin Alpha Chain (1.5 Å Resolution)',
    method: 'X-RAY DIFFRACTION',
    resolution: '1.50 Å',
    chain: 'A',
    sequence: 'VLSPADKTNVKAAWGKVGAHAGEYGAEALERMFLSFPTTKTYFPHFDLSHGSAQVKGHGKKVADALTNAVAHVDDMPNALSALSDLHAHKLRVDPVNFKLLSHCLLVTLAAHLPAEFTPAVHASLDKFLASVSTVLTSKYR',
    length: 141,
    experimentalQ3: 'CCCHHHHHHHHHHHHHHCCCCCHHHHHHHHHHHHHHCCCHHHHHHHHHCCCHHHHHHHHHHHHHHHHHHHHHHCCCCHHHHHHHHHHHHHHHCCCCCHHHHHHHHHHHHHHHHHHCCCCHHHHHHHHHHHHHHHHHHHCCCC',
    get pdbText() {
      return generateExperimentalPdbText(this.sequence!, this.experimentalQ3!, 'A');
    }
  },
  '1TIM': {
    pdbId: '1TIM',
    title: 'Triosephosphate Isomerase (TIM Barrel) at 1.9 Å Resolution',
    method: 'X-RAY DIFFRACTION',
    resolution: '1.90 Å',
    chain: 'A',
    sequence: 'ARTFFVGGNFKLNGSKQSIKEIVERLNTASIPENVEVVICPPATYLDYSVSLVKKPQVTVGAQNAYLKASGAFTGENSVDQIKDVGAKWVILGHSERRSYFHEDDKFIADKTKFALGQGVGVILCIGETLEEKKAGKTLDVVERQLNAVLEEVKDWTNVVVAYEPVWAIGTGKVATPEQAQEVHAAIRKWLISNVSAEEADKAIRVLYGGSVNPAA',
    length: 247,
    experimentalQ3: 'CCEEEECCCCCEECCCCCHHHHHHHHHHCCCCCEEEEEECCCCHHHHHHHHHHHCCEEEEEECCCHHHHHHHCCCCCHHHHHHHHHCCEEEEEECCCCCHHHHHHHHHHHHHHHHHCCCCEEEEEECCCCCHHHHHHHHHHHHHHHHHHHHHCCCCEEEEEECCCHHHHHHHHHHHHHHHHHHHHHHCCCCHHHHHHHHHHHHHHHHHHHCCCC',
    get pdbText() {
      return generateExperimentalPdbText(this.sequence!, this.experimentalQ3!, 'A');
    }
  },
  '4PTI': {
    pdbId: '4PTI',
    title: 'Bovine Pancreatic Trypsin Inhibitor (BPTI) at 1.5 Å Resolution',
    method: 'X-RAY DIFFRACTION',
    resolution: '1.50 Å',
    chain: 'A',
    sequence: 'RPDFCLEPPYTGPCKARIIRYFYNAKAGLCQTFVYGGCRAKRNNFKSAEDCMRTCGGA',
    length: 58,
    experimentalQ3: 'CCCCEECCCCEEEECCCCHHHHHHHHHCCCCEEEECCCCCCCCCHHHHHHHHCCCCCC',
    get pdbText() {
      return generateExperimentalPdbText(this.sequence!, this.experimentalQ3!, 'A');
    }
  },
  '1MBO': {
    pdbId: '1MBO',
    title: 'Sperm Whale Deoxymyoglobin at 1.4 Å Resolution',
    method: 'X-RAY DIFFRACTION',
    resolution: '1.40 Å',
    chain: 'A',
    sequence: 'VLSEGEWQLVLHVWAKVEADVAGHGQDILIRLFKSHPETLEKFDRFKHLKTEAEMKASEDLKKHGVTVLTALGAILKKKGHHEAELKPLAQSHATKHKIPIKYLEFISEAIIHVLHSRHPGDFGADAQGAMNKALELFRKDIAAKYKELGYQG',
    length: 153,
    experimentalQ3: 'CCCHHHHHHHHHHHHHHCCCCCHHHHHHHHHHHHHHCCCHHHHHHHHHCCCHHHHHHHHHHHHHHHHHHHHHHCCCCHHHHHHHHHHHHHHHCCCCCHHHHHHHHHHHHHHHHHHCCCCHHHHHHHHHHHHHHHHHHHCCCC',
    get pdbText() {
      return generateExperimentalPdbText(this.sequence!, this.experimentalQ3!, 'A');
    }
  },
  '1EMA': {
    pdbId: '1EMA',
    title: 'Green Fluorescent Protein (GFP) from Aequorea victoria',
    method: 'X-RAY DIFFRACTION',
    resolution: '1.90 Å',
    chain: 'A',
    sequence: 'MSKGEELFTGVVPILVELDGDVNGHKFSVSGEGEGDATYGKLTLKFICTTGKLPVPWPTLVTTFSYGVQCFSRYPDHMKQHDFFKSAMPEGYVQERTIFFKDDGNYKTRAEVKFEGDTLVNRIELKGIDFKEDGNILGHKLEYNYNSHNVYIMADKQKNGIKVNFKIRHNIEDGSVQLADHYQQNTPIGDGPVLLPDNHYLSTQSALSKDPNEKRDHMVLLEFVTAAGITHGMDELYK',
    length: 238,
    experimentalQ3: 'CCCCCEEEEECCCEEEEECCCCCCEEEEEECCCCCEEEEEEECCCCCEEEEECCCCCCCCCHHHHHHCCCCCCCCCCCCCCCCCCCCEEEECCCCEEEEEECCCEEEEEEECCCCCEEEEEECCCCCEEEEEEECCCCEEEEEEEECCCCEEEEEEECCCCCEEEEEEEECCCCCEEEEEEECCCCCEEEEEEECCCCEEEEEEECCCCEEEEECCCC',
    get pdbText() {
      return generateExperimentalPdbText(this.sequence!, this.experimentalQ3!, 'A');
    }
  },
  '2CRO': {
    pdbId: '2CRO',
    title: 'Bacteriophage 434 Cro Repressor Complex',
    method: 'X-RAY DIFFRACTION',
    resolution: '2.20 Å',
    chain: 'A',
    sequence: 'MQTLSERLKKRRIALKMTQTELATKAGVKQQSIQLIEAGVTKRPRFLFEIAMALNCDPVWLQYGTKRGKA',
    length: 70,
    experimentalQ3: 'CCCHHHHHHHHHHHHHCCCCCHHHHHHHCCCHHHHHHHHHCCCCCHHHHHHHHHCCCCCEEEECCCEECCC',
    get pdbText() {
      return generateExperimentalPdbText(this.sequence!, this.experimentalQ3!, 'A');
    }
  }
};
