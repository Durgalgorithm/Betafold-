import { ProteinSample, ModelMetricComparison, EpochData, ArchitectureLayer, VivaQuestion } from '../types';

export const BENCHMARK_PROTEINS: ProteinSample[] = [
  {
    id: '1crn',
    pdbId: '1CRN',
    name: 'Crambin (Plant Seed Storage Protein)',
    organism: 'Crambe hispanica',
    resolution: '0.54 Å (Ultra-high X-ray)',
    chain: 'A',
    description: 'Gold-standard benchmark test case. Compact 46-residue plant seed protein with 2 amphipathic alpha-helices and a beta-hairpin stabilized by 3 disulfide bridges.',
    sequence: 'TTCCPSIVARSNFNVCRLPGTPEAICATYTGCIIIPGATCPGDYAN',
    groundTruthQ3: 'CCCHHHHHHHHCCCCCCCHHHHHHHHHCCCCEEEECCCCCEEECCC',
    groundTruthQ8: 'CCCCHHHHHHHHHCCCCCTTHHHHHHHHCCCCEEEECCCSSSEECCC',
    knowledge: {
      functionSummary: 'Hydrophobic plant seed thionin with potent antifungal and membrane-permeabilizing activity that protects resting seeds against soil phytopathogens.',
      biologicalRole: 'Antimicrobial Plant Immunity & Seed Storage Nutrient',
      cellularLocation: 'Plant seed endosperm and cotyledons; cell wall & extracellular space',
      structuralFeatures: 'Compact 46-residue fold featuring two amphipathic alpha-helices (residues 7-19 and 23-30) packed tightly against a two-stranded antiparallel beta-sheet (residues 32-35 and 40-43), cross-linked by three conserved disulfide bridges (Cys3-Cys40, Cys4-Cys32, Cys16-Cys26).',
      diseases: [
        {
          diseaseName: 'Seed Blight & Phytopathogen Vulnerability',
          mutationType: 'Cysteine Disulfide Bridge Disruption (e.g. Cys3Ala, Cys16Ser)',
          clinicalImpact: 'Abolishes antimicrobial membrane-lytic potency against pathogenic fungi (Fusarium and Rhizoctonia), resulting in seed rotting and non-viable germplasm.',
          structuralMechanism: 'Loss of any of the three invariant disulfide bonds causes rapid cooperative unfolding of the hydrophobic core, exposing aliphatic residues to solvent aggregation.',
          severity: 'Severe'
        },
        {
          diseaseName: 'Mammalian Cytotoxicity & Hemolysis (Thionin Homolog Toxicity)',
          mutationType: 'Surface Charge Alteration (e.g. Arg/Lys substitution in basic loop)',
          clinicalImpact: 'In mammalian homologous thionin toxins (e.g., viscotoxins/purothionins), mutations altering amphipathic surface charge induce severe non-specific erythrocyte hemolysis and neuromuscular toxicity.',
          structuralMechanism: 'Altered electrostatic electrostatic binding to negatively charged mammalian phosphoinositide membranes leads to uncoordinated pore formation and calcium influx.',
          severity: 'Moderate'
        }
      ]
    }
  },
  {
    id: '1ubq',
    pdbId: '1UBQ',
    name: 'Ubiquitin (Regulatory Protein)',
    organism: 'Homo sapiens',
    resolution: '1.80 Å',
    chain: 'A',
    description: 'Canonical mixed α/β fold protein consisting of a prominent 3.5-turn alpha helix packed against a 5-stranded antiparallel beta sheet. Essential eukaryotic regulatory molecule.',
    sequence: 'MQIFVKTLTGKTITLEVEPSDTIENVKAKIQDKEGIPPDQQRLIFAGKQLEDGRTLSDYNIQKESTLHLVLRLRGG',
    groundTruthQ3: 'CEEEEEEECCCCEEEEEEECCCHHHHHHHHHHHCCCCCCHHHHEEEEEECCCCEEEEEEEECCCCEEEEEEEECCC',
    groundTruthQ8: 'CEEEEEEECCSSSEEEEEECCSHHHHHHHHHHHCTTSSCHHHHEEEEEECCCCEEEEEEEECCSSSEEEEEEECCC',
    knowledge: {
      functionSummary: 'Post-translational modifier that covalently tags target proteins to direct 26S proteasomal degradation, orchestrate DNA repair, endocytosis, and NF-κB inflammatory signaling.',
      biologicalRole: 'Ubiquitin-Proteasome System (UPS) & Intracellular Protein Homeostasis',
      cellularLocation: 'Cytoplasm, Nucleus, and Plasma Membrane; universally expressed in all eukaryotic cells',
      structuralFeatures: 'High-stability mixed α/β fold composed of a prominent central 3.5-turn amphipathic α-helix (residues 23-34) nested against a five-stranded mixed β-sheet (β1: 1-7, β2: 10-17, β3: 40-45, β4: 48-50, β5: 65-72) with a flexible C-terminal di-glycine tail (Arg72-Gly76) required for isopeptide bond formation.',
      diseases: [
        {
          diseaseName: "Alzheimer's Disease & Neurodegenerative Tauopathies",
          mutationType: 'UBB+1 Dinucleotide Deletion Frameshift (GAGAG -> GAG)',
          clinicalImpact: 'Accumulation of mutant ubiquitin in neurofibrillary tangles and neuritic plaques, precipitating severe progressive cognitive dementia, memory loss, and cortical neuronal death.',
          structuralMechanism: 'The +1 frameshift generates an aberrant 19-amino-acid C-terminal extension with a deleted terminal Gly76. UBB+1 cannot ubiquitinate targets but tenaciously binds the 26S proteasome, acting as a competitive inhibitor that paralyzes intracellular protein degradation.',
          severity: 'Severe'
        },
        {
          diseaseName: "Parkinson's Disease (Early-Onset Juvenile Parkin-Linked)",
          mutationType: 'Lys48 / Lys63 Branching Linkage Disruption',
          clinicalImpact: 'Progressive degeneration of dopaminergic neurons in the substantia nigra pars compacta, resulting in resting tremors, bradykinesia, postural instability, and Lewy body formation.',
          structuralMechanism: 'Disruption of Lys48-linked polyubiquitination prevents clearance of damaged mitochondrial outer membrane proteins (such as Parkin and PINK1 substrates), causing mitochondrial oxidative crisis and apoptosis.',
          severity: 'Severe'
        },
        {
          diseaseName: 'Angelman Syndrome & Neurodevelopmental Intellectual Disability',
          mutationType: 'UBE3A E3-Ligase Inactivating Mutations',
          clinicalImpact: 'Severe developmental delay, microcephaly, speech impairment, ataxia, and characteristic unprovoked paroxysms of laughter.',
          structuralMechanism: 'Loss of functional ubiquitin-protein ligase E3A prevents substrate-specific ubiquitin conjugation to synaptic regulatory targets, arresting dendrite spine maturation.',
          severity: 'Severe'
        }
      ]
    }
  },
  {
    id: '2hba',
    pdbId: '2HBA',
    name: 'Hemoglobin Alpha Chain',
    organism: 'Homo sapiens',
    resolution: '1.50 Å',
    chain: 'A',
    description: 'Classic all-alpha globin fold containing 7 distinct alpha-helices (A, B, C, E, F, G, H) coordinating the prosthetic heme group for reversible oxygen transport.',
    sequence: 'VLSPADKTNVKAAWGKVGAHAGEYGAEALERMFLSFPTTKTYFPHFDLSHGSAQVKGHGKKVADALTNAVAHVDDMPNALSALSDLHAHKLRVDPVNFKLLSHCLLVTLAAHLPAEFTPAVHASLDKFLASVSTVLTSKYR',
    groundTruthQ3: 'CCCHHHHHHHHHHHHHHCCCCCHHHHHHHHHHHHHHCCCHHHHHHHHHCCCHHHHHHHHHHHHHHHHHHHHHHCCCCHHHHHHHHHHHHHHHCCCCCHHHHHHHHHHHHHHHHHHCCCCHHHHHHHHHHHHHHHHHHHCCCC',
    groundTruthQ8: 'CCCHHHHHHHHHHHHHHCCCCCHHHHHHHHHHHHHHCCCHHHHHHHHHCCCHHHHHHHHHHHHHHHHHHHHHHCCCCHHHHHHHHHHHHHHHCCCCCHHHHHHHHHHHHHHHHHHCCCCHHHHHHHHHHHHHHHHHHHCCCC',
    knowledge: {
      functionSummary: 'Subunit of the heterotetrameric (α2β2) metallo-chaperoned respiratory pigment that reversibly binds molecular oxygen (O2) with allosteric cooperativity and facilitates systemic CO2/proton buffering.',
      biologicalRole: 'Erythrocyte Oxygen Delivery & Allosteric Gas Exchange',
      cellularLocation: 'Erythrocytes (Red Blood Cells); intravascular circulating blood',
      structuralFeatures: 'Classic all-α globin fold containing seven distinct amphipathic alpha helices (designated A, B, C, E, F, G, and H) without beta-strands. The hydrophobic core coordinates the prosthetic protoheme IX iron through the Proximal His87 (F8) and Distal His58 (E7) axial coordination positions.',
      diseases: [
        {
          diseaseName: "Alpha-Thalassemia (Hb Bart's Hydrops Fetalis & Hb H Disease)",
          mutationType: 'HBA1 / HBA2 Gene Deletion or Non-deletional Point Mutations (e.g. Hb Constant Spring)',
          clinicalImpact: 'In severe 4-gene deletion (Hb Bart’s), fatal intrauterine hydrops fetalis, severe fetal anasarca, and stillbirth occur. In 3-gene deletion (Hb H disease), moderate-to-severe chronic hemolytic anemia, hepatosplenomegaly, and transfusion dependency develop.',
          structuralMechanism: 'Absence or truncation of α-globin chains causes excess unpartnered β-chains and fetal γ-chains to form homotetramers (β4 and γ4). These lack allosteric cooperativity, have dangerously high oxygen affinity (fail to deliver oxygen to tissues), and precipitate as intracellular Heinz bodies that rupture erythrocyte membranes.',
          severity: 'Severe'
        },
        {
          diseaseName: 'Methemoglobinemia (Hemoglobin M Boston / Hb M Iwate)',
          mutationType: 'Distal / Proximal Histidine Missense (His58Tyr or His87Tyr)',
          clinicalImpact: 'Lifelong slate-gray cyanosis of skin, lips, and nail beds, dyspnea on mild exertion, fatigue, and headaches unresponsive to supplemental oxygen.',
          structuralMechanism: 'Replacement of catalytic histidine with tyrosine allows the phenolic oxygen to coordinate the heme iron, locking it in the oxidized ferric (Fe³⁺) state. Ferric heme cannot bind oxygen and causes allosteric conformational freezing of the remaining subunits.',
          severity: 'Moderate'
        },
        {
          diseaseName: 'Congenital Heinz Body Hemolytic Anemia (Unstable Hemoglobin)',
          mutationType: 'Alpha-Helix Disruption (e.g. Phe43Val in Helix CD or Proline insertion in Helix F)',
          clinicalImpact: 'Recurrent episodes of acute hemolysis, jaundice, dark urine, and splenomegaly triggered by oxidative stress, infection, or sulfonamide medications.',
          structuralMechanism: 'Proline or polar substitution inside the hydrophobic globin core breaks the regular i+4 alpha-helical hydrogen bonding, causing rapid heme dissociation, globin chain denaturation, and insoluble coproprecipitation on the red cell cytoskeleton.',
          severity: 'Moderate'
        }
      ]
    }
  },
  {
    id: '1tim',
    pdbId: '1TIM',
    name: 'Triosephosphate Isomerase (TIM Barrel)',
    organism: 'Saccharomyces cerevisiae',
    resolution: '1.90 Å',
    chain: 'A',
    description: 'Prototypical (β/α)8 TIM-barrel protein where 8 parallel beta strands form an inner core barrel surrounded by 8 outer alpha helices. One of nature’s most ubiquitous metabolic enzymes.',
    sequence: 'ARTFFVGGNFKLNGSKQSIKEIVERLNTASIPENVEVVICPPATYLDYSVSLVKKPQVTVGAQNAYLKASGAFTGENSVDQIKDVGAKWVILGHSERRSYFHEDDKFIADKTKFALGQGVGVILCIGETLEEKKAGKTLDVVERQLNAVLEEVKDWTNVVVAYEPVWAIGTGKVATPEQAQEVHAAIRKWLISNVSAEEADKAIRVLYGGSVNPAA',
    groundTruthQ3: 'CCEEEECCCCCEECCCCCHHHHHHHHHHCCCCCEEEEEECCCCHHHHHHHHHHHCCEEEEEECCCHHHHHHHCCCCCHHHHHHHHHCCEEEEEECCCCCHHHHHHHHHHHHHHHHHCCCCEEEEEECCCCCHHHHHHHHHHHHHHHHHHHHHCCCCEEEEEECCCHHHHHHHHHHHHHHHHHHHHHHCCCCHHHHHHHHHHHHHHHHHHHCCCC',
    groundTruthQ8: 'CCEEEECCCCCEECCCCCHHHHHHHHHHCCCCCEEEEEECCCCHHHHHHHHHHHCCEEEEEECCCHHHHHHHCCCCCHHHHHHHHHCCEEEEEECCCCCHHHHHHHHHHHHHHHHHCCCCEEEEEECCCCCHHHHHHHHHHHHHHHHHHHHHCCCCEEEEEECCCHHHHHHHHHHHHHHHHHHHHHHCCCCHHHHHHHHHHHHHHHHHHHCCCC',
    knowledge: {
      functionSummary: 'Kinetically perfect glycolytic catalyst that rapidly and stereospecifically converts dihydroxyacetone phosphate (DHAP) into D-glyceraldehyde 3-phosphate (G3P) near the diffusion-controlled limit (kcat/Km ~ 10⁸ M⁻¹s⁻¹).',
      biologicalRole: 'Glycolytic Energy Production, Gluconeogenesis & Pentose Phosphate Pathway',
      cellularLocation: 'Cytosol; omnipresent in all aerobic and anaerobic metabolizing tissues',
      structuralFeatures: 'Prototypical (β/α)8 TIM barrel (eight parallel inner beta strands surrounded by eight concentric amphipathic alpha helices). Features a conserved 10-residue mobile active-site loop 6 (residues 166-176) with catalytic Glu165 that closes over the substrate enediol intermediate to prevent toxic methylglyoxal elimination.',
      diseases: [
        {
          diseaseName: 'Triosephosphate Isomerase (TPI) Deficiency',
          mutationType: 'Dimer Interface Missense Mutation (Glu104Asp or Ile170Val)',
          clinicalImpact: 'Devastating multisystem autosomal recessive disorder manifesting in infancy with severe progressive motor neuron degeneration, lower motor neuron paralysis, diaphragm failure, and premature death in childhood.',
          structuralMechanism: 'Glu104 forms an essential inter-subunit salt bridge with Lys13 of the opposing monomer. The Glu104Asp mutation shortens the side chain by a single methylene group (-CH2-), destroying the salt bridge and destabilizing homodimer assembly. Monomers prematurely unfold and are degraded.',
          severity: 'Severe'
        },
        {
          diseaseName: 'Non-Spherocytic Hemolytic Anemia',
          mutationType: 'Active Site Loop 6 Destabilization (Phe240Leu or Cys41Tyr)',
          clinicalImpact: 'Chronic transfusion-dependent hemolytic anemia, extreme reticulocytosis, splenomegaly, and episodic hemolytic crises during minor febrile infections.',
          structuralMechanism: 'Erythrocytes depend 100% on glycolysis for ATP generation. TPI deficiency causes toxic intracellular accumulation of dihydroxyacetone phosphate (DHAP), which spontaneously decomposes into the cytotoxic reactive dicarbonyl methylglyoxal, inducing heavy erythrocyte membrane cross-linking and hemolysis.',
          severity: 'Severe'
        }
      ]
    }
  },
  {
    id: 'cb513_sample',
    pdbId: 'CB513_#142',
    name: 'CB513 Blind Test Target #142 (Ribosomal L7/L12)',
    organism: 'Escherichia coli',
    resolution: '1.70 Å',
    chain: 'A',
    description: 'Standard independent blind evaluation sequence extracted directly from the CB513 non-homologous benchmark set used to evaluate state-of-the-art secondary structure predictors.',
    sequence: 'SITKDQIIEAVAAMSVMDVVELISAMEEKFGVSAAAAVAVAAGPVEAAEEKTEFDVILKAAGANKVAVIKAVRGATGLGLKEAKDLVESAPAALKEGVSKDDAEALKKALEEAGAEVEVK',
    groundTruthQ3: 'CCCHHHHHHHHHHHHHHHHHHHHHHHHHHHCCCEEEEEEEEECCCCCHHHHHCCEEEEEECCCCCEEEEEECCCCCHHHHHHHHHHHHHCCCCCHHHHHHHHHHHHHHHHHHHCCEEEEEC',
    groundTruthQ8: 'CCCHHHHHHHHHHHHHHHHHHHHHHHHHHHCCCEEEEEEEEECCCCCHHHHHCCEEEEEECCCCCEEEEEECCCCCHHHHHHHHHHHHHCCCCCHHHHHHHHHHHHHHHHHHHCCEEEEEC',
    knowledge: {
      functionSummary: 'Dynamic mobile component of the 50S ribosomal stalk that recruits elongation factors (EF-Tu and EF-G) and stimulates GTPase activation to accelerate translation elongation rate and fidelity.',
      biologicalRole: 'Bacterial Ribosomal Protein Synthesis & GTPase Factor Recruitment',
      cellularLocation: 'Bacterial ribosome (50S large subunit stalk complex); cytoplasm',
      structuralFeatures: 'Dimeric architecture containing an extended N-terminal dimerization domain connected by a flexible glycine/alanine-rich hinge to a globular C-terminal factor-binding domain featuring a four-stranded antiparallel beta-sheet backed by three alpha-helices.',
      diseases: [
        {
          diseaseName: 'Translational Arrest & Bacterial Lethality',
          mutationType: 'Conserved Hinge Deletion or Hydrophobic Core Alanine Inversion',
          clinicalImpact: 'In microbial pathogens, abolishes bacterial translation elongation, completely arresting cellular growth and bacterial proliferation.',
          structuralMechanism: 'Loss of conformational flexibility in the hinge region prevents the C-terminal domain from swinging toward the ribosomal factor-binding center, abolishing EF-G GTPase activation.',
          severity: 'Severe'
        },
        {
          diseaseName: 'Thiopeptides & Micrococcin Antibiotic Target Vulnerability',
          mutationType: 'Ribosomal Stalk L10-L12 Docking Interface Alteration',
          clinicalImpact: 'Alters sensitivity to veterinary and investigational ribosomal stalk-targeting peptide antibiotics (e.g., thiostrepton and nosiheptide).',
          structuralMechanism: 'Mutations disrupt the antibiotic-docking pocket at the base of the ribosomal stalk, interfering with antibiotic inhibition of translocation.',
          severity: 'Moderate'
        }
      ]
    }
  }
];

export const BENCHMARK_COMPARISONS: ModelMetricComparison[] = [
  {
    modelName: 'Betafold (Our CNN-BiLSTM)',
    architectureType: '1D-CNN (K: 3,5,7) + BiLSTM (2x128) + Multi-Head Attention',
    q3Accuracy: 84.8,
    q8Accuracy: 73.6,
    sovScore: 81.4,
    helixF1: 86.2,
    sheetF1: 82.5,
    coilF1: 85.8,
    trainingTimePerEpoch: '4.2s (GPU)',
    inferenceLatency: '1.2ms/seq',
    paramCount: '1,428,643',
  },
  {
    modelName: 'Baseline BiLSTM-Only',
    architectureType: 'Embedding + 2-layer BiLSTM (2x128) + Dense',
    q3Accuracy: 78.4,
    q8Accuracy: 66.8,
    sovScore: 73.9,
    helixF1: 79.1,
    sheetF1: 74.3,
    coilF1: 81.2,
    trainingTimePerEpoch: '7.8s (GPU)',
    inferenceLatency: '2.8ms/seq',
    paramCount: '984,320',
  },
  {
    modelName: 'Baseline CNN-Only (ResNet-1D)',
    architectureType: '5 Residual 1D-CNN Blocks (K: 3,5) + Global Pool + Dense',
    q3Accuracy: 80.1,
    q8Accuracy: 68.5,
    sovScore: 75.2,
    helixF1: 81.4,
    sheetF1: 77.0,
    coilF1: 81.9,
    trainingTimePerEpoch: '3.1s (GPU)',
    inferenceLatency: '0.8ms/seq',
    paramCount: '1,120,400',
  },
  {
    modelName: 'Standard LSTM-Only',
    architectureType: 'Unidirectional LSTM (128) + Dense Head',
    q3Accuracy: 74.2,
    q8Accuracy: 62.1,
    sovScore: 68.5,
    helixF1: 75.3,
    sheetF1: 69.8,
    coilF1: 76.9,
    trainingTimePerEpoch: '6.4s (GPU)',
    inferenceLatency: '2.1ms/seq',
    paramCount: '624,192',
  },
  {
    modelName: 'Traditional Jpred / GOR IV',
    architectureType: 'Statistical Information Theory / Propensity Matrix',
    q3Accuracy: 64.9,
    q8Accuracy: 51.2,
    sovScore: 58.7,
    helixF1: 66.4,
    sheetF1: 59.2,
    coilF1: 68.1,
    trainingTimePerEpoch: 'N/A (Rule-based)',
    inferenceLatency: '4.5ms/seq',
    paramCount: 'Lookup Matrix',
  },
];

export const TRAINING_EPOCHS_DATA: EpochData[] = [
  { epoch: 1, trainLoss: 0.985, valLoss: 0.892, trainQ3: 63.4, valQ3: 67.8, trainTimeSec: 4.8 },
  { epoch: 5, trainLoss: 0.654, valLoss: 0.621, trainQ3: 75.2, valQ3: 76.4, trainTimeSec: 4.2 },
  { epoch: 10, trainLoss: 0.482, valLoss: 0.495, trainQ3: 81.6, valQ3: 80.9, trainTimeSec: 4.1 },
  { epoch: 15, trainLoss: 0.395, valLoss: 0.432, trainQ3: 85.3, valQ3: 82.7, trainTimeSec: 4.2 },
  { epoch: 20, trainLoss: 0.334, valLoss: 0.408, trainQ3: 87.9, valQ3: 83.9, trainTimeSec: 4.1 },
  { epoch: 25, trainLoss: 0.286, valLoss: 0.398, trainQ3: 89.8, valQ3: 84.4, trainTimeSec: 4.2 },
  { epoch: 30, trainLoss: 0.245, valLoss: 0.392, trainQ3: 91.5, valQ3: 84.8, trainTimeSec: 4.2 },
];

export const MODEL_ARCHITECTURE_LAYERS: ArchitectureLayer[] = [
  {
    id: 'layer_1',
    name: 'Input Feature Matrix',
    type: 'Input',
    shape: '(Batch_Size, L, 44)',
    params: 0,
    description: 'Fused representation: 20D One-Hot + 20D PSI-BLAST PSSM conservation scores + 4D Physicochemical descriptors (charge, hydrophobicity, isoelectric point, steric volume).',
    hyperparameters: { Max_Length: 'L (Variable, padded to 700)', Feature_Dim: 44 }
  },
  {
    id: 'layer_2',
    name: 'Multi-Scale 1D-CNN Block',
    type: 'Conv1D',
    shape: '(Batch_Size, L, 128)',
    params: 67584,
    description: 'Parallel 1D convolutions with receptive fields 3, 5, and 7 to capture local oligopeptide motifs, followed by Batch Normalization, ReLU activation, and Spatial Dropout.',
    hyperparameters: { Filters: 128, Kernels: '3, 5, 7', Padding: 'same', Activation: 'ReLU' }
  },
  {
    id: 'layer_3',
    name: 'Spatial Dropout & Batch Normalization',
    type: 'BatchNorm',
    shape: '(Batch_Size, L, 128)',
    params: 512,
    description: 'Normalizes activations across residue sequences to accelerate gradient propagation and prevent internal covariate shift; 25% dropout prevents motif co-adaptation.',
    hyperparameters: { Dropout_Rate: 0.25, Momentum: 0.99, Epsilon: 0.001 }
  },
  {
    id: 'layer_4',
    name: 'Bidirectional LSTM Layer 1',
    type: 'BiLSTM',
    shape: '(Batch_Size, L, 256)',
    params: 394240,
    description: 'Captures bidirectional sequence context: forward cell tracks N-to-C terminal dependencies; backward cell tracks C-to-N terminal dependencies. Essential for tertiary contact context.',
    hyperparameters: { Units_Per_Direction: 128, Recurrent_Dropout: 0.2, Return_Sequences: 'True' }
  },
  {
    id: 'layer_5',
    name: 'Bidirectional LSTM Layer 2',
    type: 'BiLSTM',
    shape: '(Batch_Size, L, 256)',
    params: 525312,
    description: 'Second-order recurrent abstraction capturing long-range hydrogen-bonding patterns between distal residues in antiparallel and parallel beta-sheet formation.',
    hyperparameters: { Units_Per_Direction: 128, Recurrent_Dropout: 0.2, Return_Sequences: 'True' }
  },
  {
    id: 'layer_6',
    name: 'Self-Attention Highway Layer',
    type: 'Attention',
    shape: '(Batch_Size, L, 256)',
    params: 197120,
    description: 'Multi-head scaled dot-product attention weighing the importance of distal residues for secondary structure stabilization with residual skip connection.',
    hyperparameters: { Num_Heads: 4, Key_Dim: 64, Residual_Skip: 'True' }
  },
  {
    id: 'layer_7',
    name: 'Fully Connected Dense Layer',
    type: 'Dense',
    shape: '(Batch_Size, L, 128)',
    params: 32896,
    description: 'Dense non-linear transformation with Swish activation and L2 regularization to condense sequence-level representations before final classification.',
    hyperparameters: { Units: 128, Activation: 'Swish', L2_Reg: '1e-4' }
  },
  {
    id: 'layer_8',
    name: 'Output Softmax Heads (Q3 / Q8)',
    type: 'Output',
    shape: '(Batch_Size, L, 3) / (Batch_Size, L, 8)',
    params: 1419,
    description: 'Dual-task classification head outputting probability distributions over 3-state (Helix, Strand, Coil) and 8-state DSSP secondary structure classes.',
    hyperparameters: { Q3_Classes: 'H, E, C', Q8_Classes: 'H, G, I, E, B, T, S, L', Loss: 'Categorical Crossentropy + SOV Loss' }
  }
];

export const VIVA_QUESTIONS: VivaQuestion[] = [
  {
    id: 'viva_1',
    category: 'Deep Learning',
    question: 'Why did you choose a hybrid CNN-BiLSTM architecture instead of using just a CNN or just a BiLSTM?',
    hint: 'Think about how local motifs vs. long-range dependencies dictate protein folding.',
    sampleAnswer: 'Proteins exhibit hierarchical structural organization. Local 1D-CNN layers with small kernels (3, 5, 7) excel at extracting immediate tripeptide and pentapeptide conformational motifs (e.g. capping boxes, turn signatures). However, secondary structures like beta-sheets require non-local interaction memory across 20-50 residues, which the Bidirectional LSTM captures through its forward and backward hidden state vectors. Combining CNN for local feature extraction with BiLSTM for sequential memory gives us the strengths of both.'
  },
  {
    id: 'viva_2',
    category: 'Bioinformatics',
    question: 'Why is the SOV (Segment Overlap Measure) score considered superior to standard Q3 accuracy in secondary structure evaluation?',
    hint: 'Consider what happens if a helix of 10 residues has a 1-residue misclassification in the middle.',
    sampleAnswer: 'Q3 accuracy measures per-residue correctness independent of context. If a 10-residue alpha helix has an isolated misclassified residue in the middle (e.g., HHHHHCHHHH), Q3 is 90%, but in reality, that disrupts the structural continuity of the hydrogen-bonded cylinder. The SOV score (Rost et al. / Zemla et al.) evaluates complete conformational segments rather than isolated points, heavily penalizing fragmented helices and rewarded continuous physical secondary structure elements.'
  },
  {
    id: 'viva_3',
    category: 'Data Pipeline',
    question: 'How does incorporating PSSM (Position-Specific Scoring Matrices) from PSI-BLAST improve model accuracy compared to raw one-hot amino acid sequences?',
    hint: 'Evolutionary conservation and tolerated substitutions.',
    sampleAnswer: 'Natural selection conserves 3D structural fold much more strongly than raw sequence identity. Two proteins with only 25% sequence identity often share virtually identical secondary and tertiary structures. A PSSM captures evolutionary substitution profiles and conservation weights across homologous families from UniProt/NCBI databases. This tells the neural network whether a residue substitution is structurally tolerated or strictly deleterious, giving the model far richer biological signal than one-hot encoding alone.'
  },
  {
    id: 'viva_4',
    category: 'Optimization',
    question: 'What specific TensorFlow and hardware optimizations did you implement to reduce training time per epoch?',
    hint: 'Mention tf.data pipeline, mixed-precision, and vectorized batch padding.',
    sampleAnswer: 'We implemented several optimizations: (1) Used the tf.data API with prefetch(tf.data.AUTOTUNE) and interleave to parallelize data loading and GPU execution, eliminating I/O bottlenecks; (2) Grouped protein sequences into length-bucketed batches (bucket_by_sequence_length) to minimize wasted zero-padding computation; (3) Enabled FP16 Mixed Precision training with tf.keras.mixed_precision.set_global_policy("mixed_float16"), doubling tensor core throughput on modern GPUs; and (4) Compiled the forward pass using tf.function(jit_compile=True) for XLA kernel fusion.'
  },
  {
    id: 'viva_5',
    category: 'Bioinformatics',
    question: 'How do you map DSSP 8-state secondary structure classes (Q8) to the standard 3-state classes (Q3)?',
    hint: 'DSSP codes: H, G, I, E, B, T, S, L.',
    sampleAnswer: 'According to the standard Rost & Sander / CASP convention: (1) Helices: Alpha-helix (H), 3-10 helix (G), and Pi-helix (I) are mapped to Helix (H); (2) Strands: Extended beta-strand (E) and isolated beta-bridge (B) are mapped to Strand (E); (3) Coils: Hydrogen-bonded turn (T), bend (S), and irregular loop (L/C) are mapped to Coil (C).'
  }
];
