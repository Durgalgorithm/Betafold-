export type SecondaryStructure3 = 'H' | 'E' | 'C'; // Helix, Strand (Sheet), Coil
export type SecondaryStructure8 = 'H' | 'G' | 'I' | 'E' | 'B' | 'T' | 'S' | 'L'; // Alpha, 3-10, Pi, Beta-strand, Beta-bridge, Turn, Bend, Loop/Coil

export interface ResiduePrediction {
  index: number;
  aminoAcid: string;
  name: string;
  q3: SecondaryStructure3;
  q8: SecondaryStructure8;
  q3Probabilities: {
    H: number;
    E: number;
    C: number;
  };
  confidence: number; // 0 to 1
  hydrophobicity: number; // Kyte-Doolittle scale
  pssmScore: number; // Conservation score
  solventAccessibility: 'Buried' | 'Intermediate' | 'Exposed';
  groundTruthQ3?: SecondaryStructure3;
  groundTruthQ8?: SecondaryStructure8;
}

export interface DiseaseImplication {
  diseaseName: string;
  mutationType: string;
  clinicalImpact: string;
  structuralMechanism: string;
  severity: 'Severe' | 'Moderate' | 'Mild' | 'Variable';
}

export interface ProteinKnowledge {
  functionSummary: string;
  biologicalRole: string;
  cellularLocation: string;
  structuralFeatures: string;
  diseases: DiseaseImplication[];
}

export interface ProteinSample {
  id: string;
  pdbId: string;
  name: string;
  organism: string;
  sequence: string;
  description: string;
  resolution?: string;
  chain?: string;
  groundTruthQ3: string;
  groundTruthQ8?: string;
  knowledge?: ProteinKnowledge;
}

export interface PredictionResult {
  proteinId: string;
  sequence: string;
  length: number;
  q3Accuracy?: number; // if ground truth available
  q8Accuracy?: number;
  sovScore?: number; // Segment Overlap Measure
  q3Distribution: {
    helixPct: number;
    sheetPct: number;
    coilPct: number;
  };
  avgConfidence: number;
  inferenceTimeMs: number;
  residues: ResiduePrediction[];
  structureSegments: {
    type: SecondaryStructure3;
    start: number;
    end: number;
    length: number;
    avgConfidence: number;
  }[];
}

export interface ModelMetricComparison {
  modelName: string;
  architectureType: string;
  q3Accuracy: number; // e.g. 84.8%
  q8Accuracy: number; // e.g. 73.6%
  sovScore: number; // e.g. 81.4%
  helixF1: number;
  sheetF1: number;
  coilF1: number;
  trainingTimePerEpoch: string; // e.g. "4.2s (GPU)"
  inferenceLatency: string; // e.g. "1.2ms/seq"
  paramCount: string;
}

export interface EpochData {
  epoch: number;
  trainLoss: number;
  valLoss: number;
  trainQ3: number;
  valQ3: number;
  trainTimeSec: number;
}

export interface ArchitectureLayer {
  id: string;
  name: string;
  type: 'Input' | 'Embedding' | 'Conv1D' | 'BatchNorm' | 'BiLSTM' | 'Attention' | 'Dense' | 'Dropout' | 'Output';
  shape: string;
  params: number;
  description: string;
  hyperparameters: Record<string, string | number>;
}

export interface VivaQuestion {
  id: string;
  category: 'Deep Learning' | 'Bioinformatics' | 'Optimization' | 'Data Pipeline';
  question: string;
  hint: string;
  sampleAnswer: string;
}

export interface ExperimentalStructureData {
  pdbId: string;
  title: string;
  method: string;
  resolution?: string;
  chain: string;
  sequence: string;
  length: number;
  experimentalQ3: string;
  experimentalQ8?: string;
  pdbText: string;
  fetchedAt?: string;
}

export interface AgreementMetrics {
  q3Accuracy: number;
  q8Accuracy?: number;
  sovScore: number;
  totalResidues: number;
  matchingResidues: number;
  mismatchingResidues: number;
  helixStats: {
    precision: number;
    recall: number;
    f1: number;
    predCount: number;
    expCount: number;
    truePositives: number;
  };
  sheetStats: {
    precision: number;
    recall: number;
    f1: number;
    predCount: number;
    expCount: number;
    truePositives: number;
  };
  coilStats: {
    precision: number;
    recall: number;
    f1: number;
    predCount: number;
    expCount: number;
    truePositives: number;
  };
}

