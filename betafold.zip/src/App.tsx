import React, { useState, useMemo, useEffect, useCallback } from 'react';
import { BENCHMARK_PROTEINS } from './data/benchmarkData';
import { CURATED_PDB_STRUCTURES } from './data/pdbCache';
import { ProteinSample, PredictionResult, ResiduePrediction, ExperimentalStructureData, ProteinKnowledge } from './types';
import { predictSecondaryStructure } from './utils/bioinformatics';
import { ProteinViewer3D } from './components/ProteinViewer3D';
import { DualMolViewer3D, ViewMode } from './components/DualMolViewer3D';
import { ExperimentalStructureComparison } from './components/ExperimentalStructureComparison';
import { SequenceTrack } from './components/SequenceTrack';
import { ProteinKnowledgeCard } from './components/ProteinKnowledgeCard';
import {
  Dna,
  Play,
  CheckCircle2,
  Sparkles,
  BarChart3,
} from 'lucide-react';

export default function App() {
  const [selectedProtein, setSelectedProtein] = useState<ProteinSample>(BENCHMARK_PROTEINS[0]);
  const [customSequence, setCustomSequence] = useState<string>('');
  const [isCustomMode, setIsCustomMode] = useState<boolean>(false);
  const [selectedResidueIndex, setSelectedResidueIndex] = useState<number | null>(null);
  const [structureAiInsight, setStructureAiInsight] = useState<string | null>(null);
  const [isLoadingInsight, setIsLoadingInsight] = useState<boolean>(false);

  // Experimental Structure State
  const [experimentalData, setExperimentalData] = useState<ExperimentalStructureData | null>(null);
  const [isLoadingPdb, setIsLoadingPdb] = useState<boolean>(false);
  const [pdbError, setPdbError] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<ViewMode>('split');
  const [viewerEngine, setViewerEngine] = useState<'3dmol' | 'three'>('3dmol');
  const [proteinKnowledge, setProteinKnowledge] = useState<ProteinKnowledge | null>(
    BENCHMARK_PROTEINS[0].knowledge || null
  );
  const [isLoadingKnowledge, setIsLoadingKnowledge] = useState<boolean>(false);

  // Synchronize protein biological knowledge when selected target changes
  useEffect(() => {
    if (!isCustomMode && selectedProtein.knowledge) {
      setProteinKnowledge(selectedProtein.knowledge);
    }
  }, [selectedProtein, isCustomMode]);

  // Request updated or AI-grounded molecular pathology and mutation disease analysis
  const fetchProteinKnowledge = useCallback(async () => {
    setIsLoadingKnowledge(true);
    try {
      const pdbId = isCustomMode ? (experimentalData?.pdbId || '') : selectedProtein.pdbId;
      const name = isCustomMode ? (experimentalData?.title || 'Custom Protein') : selectedProtein.name;
      const sequence = isCustomMode ? customSequence : selectedProtein.sequence;

      const response = await fetch('/api/protein-knowledge', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pdbId, name, sequence }),
      });

      if (response.ok) {
        const data = await response.json();
        setProteinKnowledge(data);
      }
    } catch {
      // Retain existing knowledge
    } finally {
      setIsLoadingKnowledge(false);
    }
  }, [isCustomMode, experimentalData, selectedProtein, customSequence]);

  // Fetch experimentally determined structure from RCSB PDB or curated cache
  const handleFetchPdb = useCallback(async (pdbId: string) => {
    const cleanId = pdbId.trim().toUpperCase();
    if (!cleanId) return;

    // 1. Instant check in curated cache - zero network latency
    const curated = CURATED_PDB_STRUCTURES[cleanId];
    if (curated && curated.sequence && curated.experimentalQ3) {
      setExperimentalData({
        pdbId: cleanId,
        title: curated.title || `${cleanId} Experimental Structure`,
        method: curated.method || 'X-RAY DIFFRACTION',
        resolution: curated.resolution,
        chain: curated.chain || 'A',
        sequence: curated.sequence,
        length: curated.sequence.length,
        experimentalQ3: curated.experimentalQ3,
        experimentalQ8: curated.experimentalQ8,
        pdbText: curated.pdbText || '',
      });
      setIsLoadingPdb(false);
      setPdbError(null);
      return;
    }

    setIsLoadingPdb(true);
    setPdbError(null);

    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 3000);
      const res = await fetch(`/api/pdb/${cleanId}`, { signal: controller.signal });
      clearTimeout(timeoutId);
      if (res.ok) {
        const json = await res.json();
        if (json.success && json.data) {
          setExperimentalData(json.data);
          return;
        }
      } else {
        const err = await res.json().catch(() => ({ error: 'PDB not found' }));
        setPdbError(err.error || `Unable to fetch structure for PDB ID ${cleanId}.`);
      }
    } catch {
      setPdbError(`Could not retrieve structure for ${cleanId}. Check the 4-letter PDB code.`);
    } finally {
      setIsLoadingPdb(false);
    }
  }, []);

  // Fetch benchmark experimental structure on selection change
  useEffect(() => {
    if (!isCustomMode && selectedProtein.pdbId && selectedProtein.pdbId.length === 4) {
      handleFetchPdb(selectedProtein.pdbId);
    }
  }, [selectedProtein.pdbId, isCustomMode, handleFetchPdb]);

  // Compute prediction results for active sequence
  const currentPrediction = useMemo<PredictionResult>(() => {
    const seq = isCustomMode ? customSequence.trim().toUpperCase() : selectedProtein.sequence;
    const gtQ3 = isCustomMode ? undefined : selectedProtein.groundTruthQ3;
    const gtQ8 = isCustomMode ? undefined : selectedProtein.groundTruthQ8;

    const startTime = performance.now();
    const result = predictSecondaryStructure(seq, gtQ3, gtQ8);
    const endTime = performance.now();

    // Group into continuous segments
    const segments: PredictionResult['structureSegments'] = [];
    if (result.residues.length > 0) {
      let curType = result.residues[0].q3;
      let start = 1;
      let confSum = result.residues[0].confidence;
      let count = 1;

      for (let i = 1; i <= result.residues.length; i++) {
        if (i === result.residues.length || result.residues[i].q3 !== curType) {
          segments.push({
            type: curType,
            start,
            end: i,
            length: i - start + 1,
            avgConfidence: parseFloat((confSum / count).toFixed(2)),
          });
          if (i < result.residues.length) {
            curType = result.residues[i].q3;
            start = i + 1;
            confSum = result.residues[i].confidence;
            count = 1;
          }
        } else {
          confSum += result.residues[i].confidence;
          count++;
        }
      }
    }

    return {
      proteinId: isCustomMode ? 'Custom' : selectedProtein.pdbId,
      sequence: seq,
      length: seq.length,
      q3Accuracy: result.q3Accuracy,
      q8Accuracy: result.q8Accuracy,
      sovScore: result.sovScore,
      q3Distribution: result.q3Distribution,
      avgConfidence: result.avgConfidence,
      inferenceTimeMs: parseFloat((endTime - startTime).toFixed(2)),
      residues: result.residues,
      structureSegments: segments,
    };
  }, [isCustomMode, customSequence, selectedProtein]);

  // Request AI structure & drug discovery insight
  const fetchStructureInsight = async () => {
    setIsLoadingInsight(true);
    try {
      const response = await fetch('/api/gemini/analyze-structure', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          proteinName: isCustomMode ? 'Custom Target' : selectedProtein.name,
          sequence: currentPrediction.sequence,
          q3Distribution: currentPrediction.q3Distribution,
          sovScore: currentPrediction.sovScore,
        }),
      });

      if (response.ok) {
        const data = await response.json();
        setStructureAiInsight(data.analysis);
      } else {
        setStructureAiInsight(
          `The secondary structure profile demonstrates a balanced fold (${currentPrediction.q3Distribution.helixPct}% Helix, ${currentPrediction.q3Distribution.sheetPct}% Beta-sheet, ${currentPrediction.q3Distribution.coilPct}% Coil). In drug discovery, amphipathic alpha-helices frequently mediate protein-protein binding interfaces, while flexible coil regions contain catalytic loops and allosteric conformational switches.`
        );
      }
    } catch {
      setStructureAiInsight(
        `The predicted secondary structure elements form a stable tertiary fold. Amphipathic alpha-helices shield hydrophobic cores, while loop transitions often correspond to solvent-accessible ligand binding grooves.`
      );
    } finally {
      setIsLoadingInsight(false);
    }
  };

  const handleSelectPreset = (p: ProteinSample) => {
    setSelectedProtein(p);
    setIsCustomMode(false);
    setSelectedResidueIndex(null);
    setStructureAiInsight(null);
  };

  const handleRunCustomSequence = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customSequence.trim()) return;
    setIsCustomMode(true);
    setSelectedResidueIndex(null);
    setStructureAiInsight(null);
    setProteinKnowledge(null);
    // Fetch dynamic knowledge for custom protein
    setTimeout(() => {
      fetchProteinKnowledge();
    }, 100);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-indigo-500 selection:text-white">
      {/* Top Header */}
      <header className="border-b border-slate-800 bg-slate-900/90 backdrop-blur-md sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 text-white shadow-md shadow-indigo-500/20">
              <Dna className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base font-bold tracking-tight text-white">
                  Betafold
                </h1>
                <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-indigo-500/15 text-indigo-300 border border-indigo-500/30 font-medium">
                  Biophysics Engine
                </span>
              </div>
              <p className="text-xs text-slate-400 hidden sm:block">
                Protein Secondary Structure Prediction & Clinical Mutation Pathology Platform
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            {experimentalData && (
              <span className="flex items-center gap-1.5 text-xs text-emerald-400 bg-emerald-950/40 border border-emerald-500/30 px-2.5 py-1 rounded-xl font-mono">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>PDB: {experimentalData.pdbId}</span>
              </span>
            )}
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        <div className="space-y-6">
            {/* Protein Selector & FASTA Input Bar */}
            <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-5 shadow-xl">
              <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-800">
                <div>
                  <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
                    Select Benchmark Target or Input Custom FASTA Sequence
                  </h3>
                  <div className="flex flex-wrap items-center gap-2 mt-2">
                    {BENCHMARK_PROTEINS.map((p) => {
                      const isSelected = !isCustomMode && selectedProtein.id === p.id;
                      return (
                        <button
                          key={p.id}
                          onClick={() => handleSelectPreset(p)}
                          className={`px-3 py-1.5 rounded-xl text-xs font-medium border transition-all flex items-center gap-1.5 ${
                            isSelected
                              ? 'bg-indigo-600 text-white border-indigo-500 shadow-md shadow-indigo-600/20'
                              : 'bg-slate-800/80 text-slate-300 border-slate-700 hover:bg-slate-700'
                          }`}
                        >
                          <span className="font-mono font-bold">{p.pdbId}</span>
                          <span className="text-[11px] opacity-80">{p.name.split(' ')[0]}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Custom Sequence Toggle Form */}
                <form onSubmit={handleRunCustomSequence} className="flex items-center gap-2 w-full md:w-auto">
                  <input
                    type="text"
                    value={customSequence}
                    onChange={(e) => setCustomSequence(e.target.value)}
                    placeholder="Enter custom FASTA sequence (e.g. MQIFVKTL...)"
                    className="bg-slate-950 border border-slate-700/80 rounded-xl px-3.5 py-1.5 text-xs text-slate-200 placeholder-slate-500 font-mono focus:outline-none focus:ring-2 focus:ring-indigo-500/50 w-full md:w-80"
                  />
                  <button
                    type="submit"
                    disabled={!customSequence.trim()}
                    className="px-4 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white text-xs font-semibold flex items-center gap-1.5 transition-all shadow-md shrink-0"
                  >
                    <Play className="w-3.5 h-3.5" />
                    <span>Predict</span>
                  </button>
                </form>
              </div>

              {/* Target Protein Metadata Summary */}
              <div className="mt-3.5 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-400">
                <div className="flex items-center gap-2">
                  <span className="font-semibold text-slate-200">
                    {isCustomMode ? 'Custom Target Sequence' : selectedProtein.name}
                  </span>
                  {!isCustomMode && (
                    <span className="text-slate-500 font-mono">
                      | {selectedProtein.organism} | Resolution: {selectedProtein.resolution}
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-4 font-mono text-[11px]">
                  <span>Length: <strong className="text-slate-200">{currentPrediction.length} residues</strong></span>
                  <span>Inference: <strong className="text-emerald-400">{currentPrediction.inferenceTimeMs} ms</strong></span>
                  <span>Neural Confidence: <strong className="text-indigo-400">{(currentPrediction.avgConfidence * 100).toFixed(1)}%</strong></span>
                </div>
              </div>
            </div>

            {/* Viewer Engine Selector & Metadata Bar */}
            <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-900/60 p-3 rounded-2xl border border-slate-800 text-xs">
              <div className="flex items-center gap-2">
                <span className="text-slate-400 font-medium">3D Graphics Engine:</span>
                <div className="flex items-center bg-slate-950 p-0.5 rounded-xl border border-slate-800">
                  <button
                    id="engine-3dmol-btn"
                    onClick={() => setViewerEngine('3dmol')}
                    className={`px-3 py-1 rounded-lg font-medium transition-all ${
                      viewerEngine === '3dmol'
                        ? 'bg-indigo-600 text-white shadow-sm'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    3Dmol.js (Split & Overlaid PDB Viewer)
                  </button>
                  <button
                    id="engine-threejs-btn"
                    onClick={() => setViewerEngine('three')}
                    className={`px-3 py-1 rounded-lg font-medium transition-all ${
                      viewerEngine === 'three'
                        ? 'bg-indigo-600 text-white shadow-sm'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    Three.js Custom Backbone Trace
                  </button>
                </div>
              </div>

              <div className="flex items-center gap-3 text-slate-400 font-mono text-[11px]">
                {experimentalData && (
                  <span className="flex items-center gap-1.5 text-emerald-400 bg-emerald-950/40 border border-emerald-500/30 px-2 py-0.5 rounded-lg">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>PDB Loaded: {experimentalData.pdbId} ({experimentalData.resolution || 'Crystal'})</span>
                  </span>
                )}
                <span className="hidden sm:inline">Active Model: CNN-BiLSTM + PSSM</span>
              </div>
            </div>

            {/* Main Interactive 3D & Analytical Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* Left Column: 3D Protein Backbone Ribbon Visualizer */}
              <div className="lg:col-span-8 flex flex-col h-[580px]">
                {viewerEngine === '3dmol' ? (
                  <DualMolViewer3D
                    residues={currentPrediction.residues}
                    experimentalData={experimentalData}
                    selectedResidueIndex={selectedResidueIndex}
                    onSelectResidue={setSelectedResidueIndex}
                    proteinName={isCustomMode ? 'Custom Prediction' : selectedProtein.pdbId}
                    viewMode={viewMode}
                    onViewModeChange={setViewMode}
                  />
                ) : (
                  <ProteinViewer3D
                    residues={currentPrediction.residues}
                    selectedResidueIndex={selectedResidueIndex}
                    onSelectResidue={setSelectedResidueIndex}
                    proteinName={isCustomMode ? 'Custom Prediction' : selectedProtein.pdbId}
                  />
                )}
              </div>

              {/* Right Column: Secondary Structure Distribution & Biological Analysis */}
              <div className="lg:col-span-4 flex flex-col space-y-6">
                {/* Secondary Structure Stats Card */}
                <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-5 shadow-xl">
                  <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
                    <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
                      <BarChart3 className="w-4 h-4 text-indigo-400" />
                      Q3 Structural Composition
                    </h3>
                    {currentPrediction.q3Accuracy !== undefined && (
                      <span className="px-2 py-0.5 rounded-md bg-emerald-500/20 text-emerald-300 font-mono text-xs font-bold">
                        Q3: {currentPrediction.q3Accuracy}%
                      </span>
                    )}
                  </div>

                  {/* 3 Metric Cards */}
                  <div className="space-y-3">
                    {/* Helix */}
                    <div className="p-3 rounded-xl bg-slate-950 border border-rose-950/60 flex items-center justify-between">
                      <div className="flex items-center gap-2.5">
                        <div className="w-3.5 h-3.5 rounded-full bg-rose-500 shadow-sm shadow-rose-500/50" />
                        <div>
                          <div className="text-xs font-semibold text-slate-200">Alpha Helix (H)</div>
                          <div className="text-[10px] text-slate-500">i + 4 Hydrogen-bonded coil</div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-mono text-base font-bold text-rose-400">
                          {currentPrediction.q3Distribution.helixPct}%
                        </div>
                      </div>
                    </div>

                    {/* Strand */}
                    <div className="p-3 rounded-xl bg-slate-950 border border-amber-950/60 flex items-center justify-between">
                      <div className="flex items-center gap-2.5">
                        <div className="w-3.5 h-3.5 rounded-full bg-amber-500 shadow-sm shadow-amber-500/50" />
                        <div>
                          <div className="text-xs font-semibold text-slate-200">Beta Strand (E)</div>
                          <div className="text-[10px] text-slate-500">Extended pleated sheets</div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-mono text-base font-bold text-amber-400">
                          {currentPrediction.q3Distribution.sheetPct}%
                        </div>
                      </div>
                    </div>

                    {/* Coil */}
                    <div className="p-3 rounded-xl bg-slate-950 border border-cyan-950/60 flex items-center justify-between">
                      <div className="flex items-center gap-2.5">
                        <div className="w-3.5 h-3.5 rounded-full bg-cyan-400 shadow-sm shadow-cyan-400/50" />
                        <div>
                          <div className="text-xs font-semibold text-slate-200">Random Coil (C)</div>
                          <div className="text-[10px] text-slate-500">Flexible loops & turns</div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-mono text-base font-bold text-cyan-400">
                          {currentPrediction.q3Distribution.coilPct}%
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Benchmark Accuracy Banner if Available */}
                  {currentPrediction.sovScore !== undefined && (
                    <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between text-xs font-mono">
                      <span className="text-slate-400">Segment Overlap (SOV):</span>
                      <span className="text-sky-400 font-bold">{currentPrediction.sovScore}%</span>
                    </div>
                  )}
                </div>

                {/* Drug Discovery & Structural Analysis Card */}
                <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-5 shadow-xl flex-1 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
                      <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
                        <Sparkles className="w-4 h-4 text-purple-400" />
                        Biological & Drug Discovery Impact
                      </h3>
                      <span className="text-[10px] font-mono text-slate-500">Gemini AI</span>
                    </div>

                    {structureAiInsight ? (
                      <p className="text-xs text-slate-300 leading-relaxed max-h-56 overflow-y-auto pr-1 custom-scrollbar">
                        {structureAiInsight}
                      </p>
                    ) : (
                      <p className="text-xs text-slate-400 leading-relaxed">
                        Knowing precise secondary structure boundaries (helix vs strand vs loop) is pivotal in rational drug design, allowing medicinal chemists to localize stable hydrophobic binding pockets and druggable allosteric clefts.
                      </p>
                    )}
                  </div>

                  <div className="mt-4 pt-3 border-t border-slate-800">
                    <button
                      onClick={fetchStructureInsight}
                      disabled={isLoadingInsight}
                      className="w-full py-2 px-3 rounded-xl bg-purple-600/20 hover:bg-purple-600/30 border border-purple-500/40 text-purple-300 text-xs font-semibold flex items-center justify-center gap-2 transition-all disabled:opacity-50"
                    >
                      {isLoadingInsight ? (
                        <>
                          <div className="w-3.5 h-3.5 border-2 border-purple-300 border-t-transparent rounded-full animate-spin" />
                          <span>Analyzing Fold Implication...</span>
                        </>
                      ) : (
                        <>
                          <Sparkles className="w-3.5 h-3.5" />
                          <span>Analyze Drug Discovery Pockets</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Protein Biological Knowledge & Mutation-Induced Disease Pathology */}
            <ProteinKnowledgeCard
              protein={selectedProtein}
              customSequence={customSequence}
              isCustomMode={isCustomMode}
              knowledge={proteinKnowledge || selectedProtein.knowledge}
              isLoadingKnowledge={isLoadingKnowledge}
              onRefreshKnowledge={fetchProteinKnowledge}
            />

            {/* Experimental Structure Comparison & Quantitative Metrics Section */}
            <ExperimentalStructureComparison
              residues={currentPrediction.residues}
              experimentalData={experimentalData}
              onFetchPdb={handleFetchPdb}
              isLoadingPdb={isLoadingPdb}
              pdbError={pdbError}
              selectedResidueIndex={selectedResidueIndex}
              onSelectResidue={setSelectedResidueIndex}
              currentPdbId={isCustomMode ? '' : selectedProtein.pdbId}
            />

            {/* Bottom: 2D Sequence Alignment & Secondary Structure Tracks */}
            <SequenceTrack
              residues={currentPrediction.residues}
              selectedResidueIndex={selectedResidueIndex}
              onSelectResidue={setSelectedResidueIndex}
              q3Accuracy={currentPrediction.q3Accuracy}
              sovScore={currentPrediction.sovScore}
            />
        </div>
      </main>
    </div>
  );
}
