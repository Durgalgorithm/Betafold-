import { ResiduePrediction, SecondaryStructure3, SecondaryStructure8 } from '../types';

export const AMINO_ACID_NAMES: Record<string, string> = {
  A: 'Alanine',
  R: 'Arginine',
  N: 'Asparagine',
  D: 'Aspartate',
  C: 'Cysteine',
  Q: 'Glutamine',
  E: 'Glutamate',
  G: 'Glycine',
  H: 'Histidine',
  I: 'Isoleucine',
  L: 'Leucine',
  K: 'Lysine',
  M: 'Methionine',
  F: 'Phenylalanine',
  P: 'Proline',
  S: 'Serine',
  T: 'Threonine',
  W: 'Tryptophan',
  Y: 'Tyrosine',
  V: 'Valine',
};

// Kyte-Doolittle Hydrophobicity Index (-4.5 to +4.5)
export const HYDROPHOBICITY: Record<string, number> = {
  I: 4.5, V: 4.2, L: 3.8, F: 2.8, C: 2.5,
  M: 1.9, A: 1.8, G: -0.4, T: -0.7, S: -0.8,
  W: -0.9, Y: -1.3, P: -1.6, H: -3.2, E: -3.5,
  Q: -3.5, D: -3.5, N: -3.5, K: -3.9, R: -4.5
};

// Secondary structure propensities (Chou-Fasman derived baseline)
export const PROPENSITIES: Record<string, { H: number; E: number; C: number }> = {
  E: { H: 1.51, E: 0.37, C: 0.74 },
  M: { H: 1.45, E: 1.05, C: 0.60 },
  A: { H: 1.42, E: 0.83, C: 0.66 },
  L: { H: 1.21, E: 1.30, C: 0.59 },
  K: { H: 1.16, E: 0.74, C: 1.01 },
  F: { H: 1.13, E: 1.38, C: 0.71 },
  Q: { H: 1.11, E: 1.10, C: 0.98 },
  W: { H: 1.08, E: 1.37, C: 0.96 },
  I: { H: 1.08, E: 1.60, C: 0.47 },
  V: { H: 1.06, E: 1.70, C: 0.50 },
  D: { H: 1.01, E: 0.54, C: 1.46 },
  H: { H: 1.00, E: 0.87, C: 0.95 },
  R: { H: 0.98, E: 0.93, C: 0.95 },
  T: { H: 0.83, E: 1.19, C: 0.96 },
  S: { H: 0.77, E: 0.75, C: 1.43 },
  C: { H: 0.70, E: 1.19, C: 1.19 },
  Y: { H: 0.69, E: 1.47, C: 1.14 },
  N: { H: 0.67, E: 0.89, C: 1.56 },
  P: { H: 0.57, E: 0.55, C: 1.52 },
  G: { H: 0.57, E: 0.75, C: 1.56 }
};

// Convert DSSP 8-state to standard 3-state
export function q8ToQ3(q8: SecondaryStructure8 | string): SecondaryStructure3 {
  switch (q8) {
    case 'H': // Alpha helix
    case 'G': // 3-10 helix
    case 'I': // Pi helix
      return 'H';
    case 'E': // Beta strand
    case 'B': // Isolated beta-bridge
      return 'E';
    case 'T': // Hydrogen bonded turn
    case 'S': // Bend
    case 'L': // Loop / irregular
    case 'C': // Coil
    default:
      return 'C';
  }
}

/**
 * Calculates Segment Overlap Measure (SOV)
 * Standard bioinformatics score (Zemla et al. 1999) used in CASP and CB513 benchmarks
 */
export function calculateSOV(obsSeq: string, prdSeq: string): number {
  if (!obsSeq || !prdSeq || obsSeq.length !== prdSeq.length || obsSeq.length === 0) {
    return 0;
  }

  interface Segment {
    type: string;
    start: number;
    end: number;
    len: number;
  }

  function getSegments(seq: string): Segment[] {
    const segments: Segment[] = [];
    if (seq.length === 0) return segments;

    let currType = seq[0];
    let start = 0;

    for (let i = 1; i <= seq.length; i++) {
      if (i === seq.length || seq[i] !== currType) {
        segments.push({
          type: currType,
          start,
          end: i - 1,
          len: i - start,
        });
        if (i < seq.length) {
          currType = seq[i];
          start = i;
        }
      }
    }
    return segments;
  }

  const sObs = getSegments(obsSeq);
  const sPrd = getSegments(prdSeq);

  let sovSum = 0;
  let normalizer = 0;

  for (const s1 of sObs) {
    normalizer += s1.len;
    // find overlapping segments in sPrd of same type
    let matched = false;
    for (const s2 of sPrd) {
      if (s1.type === s2.type) {
        const oStart = Math.max(s1.start, s2.start);
        const oEnd = Math.min(s1.end, s2.end);
        const overlap = oEnd - oStart + 1;

        if (overlap > 0) {
          matched = true;
          const minov = overlap;
          const maxov = Math.max(s1.end, s2.end) - Math.min(s1.start, s2.start) + 1;
          const delta = Math.min(
            maxov - minov,
            minov,
            Math.floor(s1.len / 2),
            Math.floor(s2.len / 2)
          );
          sovSum += ((minov + delta) / maxov) * s1.len;
          break;
        }
      }
    }
    if (!matched) {
      // no overlap found for segment
    }
  }

  if (normalizer === 0) return 0;
  const sov = (sovSum / normalizer) * 100;
  return Math.min(100, Math.max(0, parseFloat(sov.toFixed(1))));
}

/**
 * Simulates the CNN-BiLSTM forward pass for a sequence.
 * Blends local motif convolutions (window sizes 3, 5, 7)
 * with bidirectional recurrent sequence context (forward + backward states)
 * and PSSM conservation profiles.
 */
export function predictSecondaryStructure(
  sequence: string,
  groundTruthQ3?: string,
  groundTruthQ8?: string
): {
  residues: ResiduePrediction[];
  q3Accuracy?: number;
  q8Accuracy?: number;
  sovScore?: number;
  q3Distribution: { helixPct: number; sheetPct: number; coilPct: number };
  avgConfidence: number;
} {
  const cleanSeq = sequence.toUpperCase().replace(/[^A-Z]/g, '');
  const len = cleanSeq.length;
  const residues: ResiduePrediction[] = [];

  // Window context aggregation simulating CNN local receptive field (filter sizes 3, 5, 7)
  const cnnFeatures: { H: number; E: number; C: number }[] = [];

  for (let i = 0; i < len; i++) {
    const aa = cleanSeq[i];
    const base = PROPENSITIES[aa] || { H: 1.0, E: 1.0, C: 1.0 };

    // Convolve with neighboring residues (window of 5)
    let convH = base.H * 1.5;
    let convE = base.E * 1.5;
    let convC = base.C * 1.5;
    let weightSum = 1.5;

    for (let offset = -3; offset <= 3; offset++) {
      if (offset === 0) continue;
      const idx = i + offset;
      if (idx >= 0 && idx < len) {
        const neighborAA = cleanSeq[idx];
        const nProp = PROPENSITIES[neighborAA] || { H: 1.0, E: 1.0, C: 1.0 };
        const weight = 1 / (Math.abs(offset) + 0.8);
        convH += nProp.H * weight;
        convE += nProp.E * weight;
        convC += nProp.C * weight;
        weightSum += weight;
      }
    }

    cnnFeatures.push({
      H: convH / weightSum,
      E: convE / weightSum,
      C: convC / weightSum,
    });
  }

  // BiLSTM recurrent memory pass (forward state + backward state smoothing)
  // Ensures secondary structure elements form continuous segments (helices >= 4 residues, sheets >= 2-3 residues)
  const forwardState: { H: number; E: number; C: number }[] = [];
  let currH = 1.0, currE = 1.0, currC = 1.0;
  const alphaDecay = 0.65;

  for (let i = 0; i < len; i++) {
    currH = currH * (1 - alphaDecay) + cnnFeatures[i].H * alphaDecay;
    currE = currE * (1 - alphaDecay) + cnnFeatures[i].E * alphaDecay;
    currC = currC * (1 - alphaDecay) + cnnFeatures[i].C * alphaDecay;
    forwardState.push({ H: currH, E: currE, C: currC });
  }

  const backwardState: { H: number; E: number; C: number }[] = new Array(len);
  currH = 1.0; currE = 1.0; currC = 1.0;

  for (let i = len - 1; i >= 0; i--) {
    currH = currH * (1 - alphaDecay) + cnnFeatures[i].H * alphaDecay;
    currE = currE * (1 - alphaDecay) + cnnFeatures[i].E * alphaDecay;
    currC = currC * (1 - alphaDecay) + cnnFeatures[i].C * alphaDecay;
    backwardState[i] = { H: currH, E: currE, C: currC };
  }

  // Softmax prediction head & PSSM conservation profiling
  let totalConfidence = 0;
  let countH = 0;
  let countE = 0;
  let countC = 0;
  let predQ3Str = '';

  for (let i = 0; i < len; i++) {
    const aa = cleanSeq[i];
    const fwd = forwardState[i];
    const bwd = backwardState[i];

    // Combine forward, backward, and CNN skip-connection
    let logitH = (fwd.H * 0.4 + bwd.H * 0.4 + cnnFeatures[i].H * 0.2) * 1.8;
    let logitE = (fwd.E * 0.4 + bwd.E * 0.4 + cnnFeatures[i].E * 0.2) * 1.9;
    let logitC = (fwd.C * 0.4 + bwd.C * 0.4 + cnnFeatures[i].C * 0.2) * 1.5;

    // Terminal residues (N-term and C-term) naturally favor random coil
    if (i < 3 || i >= len - 3) {
      logitC += 0.8;
      logitH -= 0.5;
      logitE -= 0.5;
    }

    // Proline is a known helix-breaker
    if (aa === 'P') {
      logitH -= 1.2;
      logitC += 0.8;
    }

    // Glycine provides high conformational flexibility (favors coil/turns)
    if (aa === 'G') {
      logitH -= 0.6;
      logitC += 0.7;
    }

    // Softmax normalization
    const expH = Math.exp(logitH);
    const expE = Math.exp(logitE);
    const expC = Math.exp(logitC);
    const sumExp = expH + expE + expC;

    const probH = expH / sumExp;
    const probE = expE / sumExp;
    const probC = expC / sumExp;

    let q3: SecondaryStructure3 = 'C';
    let maxP = probC;

    if (probH > maxP && probH > probE) {
      q3 = 'H';
      maxP = probH;
    } else if (probE > maxP) {
      q3 = 'E';
      maxP = probE;
    }

    // Q8 mapping based on sub-features
    let q8: SecondaryStructure8 = 'L';
    if (q3 === 'H') {
      q8 = probH > 0.85 ? 'H' : (i % 5 === 0 ? 'G' : 'H');
    } else if (q3 === 'E') {
      q8 = probE > 0.8 ? 'E' : 'B';
    } else {
      q8 = probC > 0.75 ? 'L' : (aa === 'P' || aa === 'G' ? 'T' : 'S');
    }

    predQ3Str += q3;
    if (q3 === 'H') countH++;
    else if (q3 === 'E') countE++;
    else countC++;

    totalConfidence += maxP;

    const hydro = HYDROPHOBICITY[aa] ?? 0;
    const pssmVal = Math.round(5 + (maxP * 8) + (hydro > 0 ? 2 : -1));

    residues.push({
      index: i + 1,
      aminoAcid: aa,
      name: AMINO_ACID_NAMES[aa] || aa,
      q3,
      q8,
      q3Probabilities: {
        H: parseFloat(probH.toFixed(3)),
        E: parseFloat(probE.toFixed(3)),
        C: parseFloat(probC.toFixed(3)),
      },
      confidence: parseFloat(maxP.toFixed(3)),
      hydrophobicity: hydro,
      pssmScore: Math.max(1, Math.min(15, pssmVal)),
      solventAccessibility: hydro > 2.0 ? 'Buried' : hydro < -1.5 ? 'Exposed' : 'Intermediate',
      groundTruthQ3: groundTruthQ3 ? (groundTruthQ3[i] as SecondaryStructure3) : undefined,
      groundTruthQ8: groundTruthQ8 ? (groundTruthQ8[i] as SecondaryStructure8) : undefined,
    });
  }

  // Calculate benchmark metrics if ground truth is available
  let q3Acc: number | undefined;
  let q8Acc: number | undefined;
  let sov: number | undefined;

  if (groundTruthQ3 && groundTruthQ3.length === len) {
    let correct = 0;
    for (let i = 0; i < len; i++) {
      if (predQ3Str[i] === groundTruthQ3[i]) correct++;
    }
    q3Acc = parseFloat(((correct / len) * 100).toFixed(1));
    sov = calculateSOV(groundTruthQ3, predQ3Str);
  }

  if (groundTruthQ8 && groundTruthQ8.length === len) {
    let correct8 = 0;
    for (let i = 0; i < len; i++) {
      if (residues[i].q8 === groundTruthQ8[i]) correct8++;
    }
    q8Acc = parseFloat(((correct8 / len) * 100).toFixed(1));
  }

  return {
    residues,
    q3Accuracy: q3Acc,
    q8Accuracy: q8Acc,
    sovScore: sov,
    q3Distribution: {
      helixPct: Math.round((countH / len) * 100),
      sheetPct: Math.round((countE / len) * 100),
      coilPct: Math.round((countC / len) * 100),
    },
    avgConfidence: parseFloat((totalConfidence / len).toFixed(3)),
  };
}

/**
 * Generates 3D coordinates for C-alpha protein backbone conforming to secondary structures:
 * - Alpha-helices: tight right-handed cylinder (radius ~2.3Å, pitch 5.4Å / 3.6 residues per turn)
 * - Beta-sheets: undulating extended zig-zag strands (~3.4Å per residue)
 * - Random coils: gentle smooth interpolating curves
 */
export function generateBackbone3DCoordinates(residues: ResiduePrediction[]): {
  points: { x: number; y: number; z: number; q3: SecondaryStructure3; index: number; aa: string }[];
  center: { x: number; y: number; z: number };
} {
  const points: { x: number; y: number; z: number; q3: SecondaryStructure3; index: number; aa: string }[] = [];

  let cx = 0, cy = 0, cz = 0;
  let currentTheta = 0;
  let currentDirX = 0, currentDirY = 1, currentDirZ = 0;

  for (let i = 0; i < residues.length; i++) {
    const res = residues[i];
    const q3 = res.q3;

    if (q3 === 'H') {
      // Helical conformation
      currentTheta += (Math.PI * 2) / 3.6; // 3.6 residues per turn
      const radius = 2.4;
      const step = 1.5; // 1.5 Å per residue along helix axis
      const hx = cx + Math.cos(currentTheta) * radius;
      const hy = cy + step;
      const hz = cz + Math.sin(currentTheta) * radius;
      points.push({ x: hx, y: hy, z: hz, q3, index: res.index, aa: res.aminoAcid });
      cy += step;
    } else if (q3 === 'E') {
      // Beta-sheet extended conformation (pleated sheet)
      const pleat = (i % 2 === 0 ? 1 : -1) * 0.9;
      cx += pleat;
      cy += 3.3; // Extended ~3.3-3.5 Å per residue
      cz += (Math.sin(i * 0.5) * 0.4);
      points.push({ x: cx, y: cy, z: cz, q3, index: res.index, aa: res.aminoAcid });
    } else {
      // Coil / loop conformation (smooth wandering turns)
      const turnAngle = (i * 0.7);
      cx += Math.cos(turnAngle) * 2.2;
      cy += Math.sin(turnAngle * 0.5) * 2.2;
      cz += Math.sin(turnAngle) * 2.0;
      points.push({ x: cx, y: cy, z: cz, q3, index: res.index, aa: res.aminoAcid });
    }
  }

  // Calculate bounding center for orbit camera
  let minX = Infinity, maxX = -Infinity;
  let minY = Infinity, maxY = -Infinity;
  let minZ = Infinity, maxZ = -Infinity;

  points.forEach((p) => {
    minX = Math.min(minX, p.x); maxX = Math.max(maxX, p.x);
    minY = Math.min(minY, p.y); maxY = Math.max(maxY, p.y);
    minZ = Math.min(minZ, p.z); maxZ = Math.max(maxZ, p.z);
  });

  const center = {
    x: (minX + maxX) / 2,
    y: (minY + maxY) / 2,
    z: (minZ + maxZ) / 2,
  };

  // Center the points around origin (0, 0, 0)
  const centeredPoints = points.map((p) => ({
    ...p,
    x: p.x - center.x,
    y: p.y - center.y,
    z: p.z - center.z,
  }));

  return { points: centeredPoints, center: { x: 0, y: 0, z: 0 } };
}

export const AA1_TO_3: Record<string, string> = {
  A: 'ALA', R: 'ARG', N: 'ASN', D: 'ASP', C: 'CYS', Q: 'GLN', E: 'GLU', G: 'GLY',
  H: 'HIS', I: 'ILE', L: 'LEU', K: 'LYS', M: 'MET', F: 'PHE', P: 'PRO', S: 'SER',
  T: 'THR', W: 'TRP', Y: 'TYR', V: 'VAL'
};

/**
 * Converts predicted secondary structure residue coordinates into valid standard PDB format
 * with HELIX, SHEET, and ATOM (N, CA, C, O) records so that molecular viewers like 3Dmol.js
 * render ribbon cartoons with alpha-helices and beta-strands.
 */
export function generatePredictedPdbText(residues: ResiduePrediction[], chainId: string = 'A'): string {
  if (!residues || residues.length === 0) return '';

  const lines: string[] = [];
  lines.push('HEADER    BETAFOLD PREDICTED SECONDARY STRUCTURE MODEL');
  lines.push(`COMPND    MOL_ID: 1; MOLECULE: BETAFOLD NEURAL PREDICTION; CHAIN: ${chainId}`);

  // Group continuous segments for HELIX and SHEET header records
  let helixCount = 1;
  let sheetCount = 1;
  let curType = '';
  let segStart = 1;

  for (let i = 0; i <= residues.length; i++) {
    const isEnd = i === residues.length;
    const type = isEnd ? '' : residues[i].q3;

    if (type !== curType || isEnd) {
      if (curType === 'H' && (i - segStart >= 2)) {
        const startRes = residues[segStart - 1];
        const endRes = residues[i - 1];
        const len = i - segStart + 1;
        const hNum = String(helixCount).padStart(3, ' ');
        const sRes = String(segStart).padStart(4, ' ');
        const eRes = String(i).padStart(4, ' ');
        const sAA = AA1_TO_3[startRes.aminoAcid] || 'ALA';
        const eAA = AA1_TO_3[endRes.aminoAcid] || 'ALA';
        lines.push(`HELIX  ${hNum} ${hNum} ${sAA} ${chainId} ${sRes}  ${eAA} ${chainId} ${eRes}  1                              ${String(len).padStart(2, ' ')}`);
        helixCount++;
      } else if (curType === 'E' && (i - segStart >= 1)) {
        const startRes = residues[segStart - 1];
        const endRes = residues[i - 1];
        const sRes = String(segStart).padStart(4, ' ');
        const eRes = String(i).padStart(4, ' ');
        const sAA = AA1_TO_3[startRes.aminoAcid] || 'VAL';
        const eAA = AA1_TO_3[endRes.aminoAcid] || 'VAL';
        lines.push(`SHEET  ${String(sheetCount).padStart(3, ' ')}   A 1 ${sAA} ${chainId}${sRes}  ${eAA} ${chainId}${eRes}  0`);
        sheetCount++;
      }
      curType = type;
      segStart = i + 1;
    }
  }

  // Generate backbone 3D coordinates
  const { points } = generateBackbone3DCoordinates(residues);

  let atomSerial = 1;
  for (let i = 0; i < residues.length; i++) {
    const res = residues[i];
    const pt = points[i];
    const aa3 = AA1_TO_3[res.aminoAcid] || 'ALA';
    const resNum = String(res.index).padStart(4, ' ');
    const bFactor = (res.confidence * 100).toFixed(2).padStart(6, ' ');

    // Primary CA atom
    const caX = pt.x.toFixed(3).padStart(8, ' ');
    const caY = pt.y.toFixed(3).padStart(8, ' ');
    const caZ = pt.z.toFixed(3).padStart(8, ' ');
    const caSerial = String(atomSerial++).padStart(5, ' ');
    lines.push(`ATOM  ${caSerial}  CA  ${aa3} ${chainId}${resNum}    ${caX}${caY}${caZ}  1.00 ${bFactor}           C`);

    // Virtual N atom
    const nX = (pt.x - 0.7).toFixed(3).padStart(8, ' ');
    const nY = (pt.y - 0.9).toFixed(3).padStart(8, ' ');
    const nZ = (pt.z + 0.3).toFixed(3).padStart(8, ' ');
    const nSerial = String(atomSerial++).padStart(5, ' ');
    lines.push(`ATOM  ${nSerial}  N   ${aa3} ${chainId}${resNum}    ${nX}${nY}${nZ}  1.00 ${bFactor}           N`);

    // Virtual C atom
    const cX = (pt.x + 0.8).toFixed(3).padStart(8, ' ');
    const cY = (pt.y + 0.8).toFixed(3).padStart(8, ' ');
    const cZ = (pt.z - 0.2).toFixed(3).padStart(8, ' ');
    const cSerial = String(atomSerial++).padStart(5, ' ');
    lines.push(`ATOM  ${cSerial}  C   ${aa3} ${chainId}${resNum}    ${cX}${cY}${cZ}  1.00 ${bFactor}           C`);

    // Virtual O atom
    const oX = (pt.x + 0.9).toFixed(3).padStart(8, ' ');
    const oY = (pt.y + 1.6).toFixed(3).padStart(8, ' ');
    const oZ = (pt.z + 0.4).toFixed(3).padStart(8, ' ');
    const oSerial = String(atomSerial++).padStart(5, ' ');
    lines.push(`ATOM  ${oSerial}  O   ${aa3} ${chainId}${resNum}    ${oX}${oY}${oZ}  1.00 ${bFactor}           O`);
  }

  lines.push('END');
  return lines.join('\n');
}

/**
 * Generates valid standard PDB file format representation directly from experimental sequence and Q3 ground truth
 * for instantaneous 3D rendering without blocking on remote external PDB database downloads.
 */
export function generateExperimentalPdbText(sequence: string, q3String: string, chainId: string = 'A'): string {
  if (!sequence || !q3String) return '';
  const len = Math.min(sequence.length, q3String.length);
  const residues: ResiduePrediction[] = [];
  for (let i = 0; i < len; i++) {
    const aa = sequence[i];
    const q3 = (q3String[i] === 'H' || q3String[i] === 'E' || q3String[i] === 'C') ? (q3String[i] as SecondaryStructure3) : 'C';
    residues.push({
      index: i + 1,
      aminoAcid: aa,
      name: AMINO_ACID_NAMES[aa] || aa,
      q3,
      q8: q3 === 'H' ? 'H' : q3 === 'E' ? 'E' : 'L',
      q3Probabilities: { H: q3 === 'H' ? 0.98 : 0.01, E: q3 === 'E' ? 0.98 : 0.01, C: q3 === 'C' ? 0.98 : 0.01 },
      confidence: 0.99,
      hydrophobicity: HYDROPHOBICITY[aa] ?? 0,
      pssmScore: 10,
      solventAccessibility: 'Intermediate',
    });
  }
  return generatePredictedPdbText(residues, chainId);
}

/**
 * Computes deep agreement metrics between Betafold prediction and experimental PDB ground truth.
 */
export function calculateAgreementMetrics(
  predResidues: ResiduePrediction[],
  expQ3: string,
  expQ8?: string
) {
  const len = Math.min(predResidues.length, expQ3.length);
  let matching = 0;
  let correct8 = 0;

  let hTP = 0, hFP = 0, hFN = 0, hPred = 0, hExp = 0;
  let eTP = 0, eFP = 0, eFN = 0, ePred = 0, eExp = 0;
  let cTP = 0, cFP = 0, cFN = 0, cPred = 0, cExp = 0;

  const predQ3Str = predResidues.slice(0, len).map((r) => r.q3).join('');
  const trimmedExpQ3 = expQ3.slice(0, len);

  for (let i = 0; i < len; i++) {
    const p = predResidues[i].q3;
    const e = trimmedExpQ3[i];

    if (p === e) matching++;

    if (expQ8 && i < expQ8.length && predResidues[i].q8 === expQ8[i]) {
      correct8++;
    }

    if (p === 'H') hPred++;
    if (e === 'H') hExp++;
    if (p === 'H' && e === 'H') hTP++;
    if (p === 'H' && e !== 'H') hFP++;
    if (p !== 'H' && e === 'H') hFN++;

    if (p === 'E') ePred++;
    if (e === 'E') eExp++;
    if (p === 'E' && e === 'E') eTP++;
    if (p === 'E' && e !== 'E') eFP++;
    if (p !== 'E' && e === 'E') eFN++;

    if (p === 'C') cPred++;
    if (e === 'C') cExp++;
    if (p === 'C' && e === 'C') cTP++;
    if (p === 'C' && e !== 'C') cFP++;
    if (p !== 'C' && e === 'C') cFN++;
  }

  const calcF1 = (tp: number, fp: number, fn: number) => {
    const prec = tp + fp > 0 ? (tp / (tp + fp)) * 100 : 0;
    const rec = tp + fn > 0 ? (tp / (tp + fn)) * 100 : 0;
    const f1 = prec + rec > 0 ? (2 * prec * rec) / (prec + rec) : 0;
    return {
      precision: parseFloat(prec.toFixed(1)),
      recall: parseFloat(rec.toFixed(1)),
      f1: parseFloat(f1.toFixed(1)),
    };
  };

  const hStats = calcF1(hTP, hFP, hFN);
  const eStats = calcF1(eTP, eFP, eFN);
  const cStats = calcF1(cTP, cFP, cFN);

  const q3Accuracy = len > 0 ? parseFloat(((matching / len) * 100).toFixed(1)) : 0;
  const q8Accuracy = expQ8 && len > 0 ? parseFloat(((correct8 / len) * 100).toFixed(1)) : undefined;
  const sovScore = calculateSOV(trimmedExpQ3, predQ3Str);

  return {
    q3Accuracy,
    q8Accuracy,
    sovScore,
    totalResidues: len,
    matchingResidues: matching,
    mismatchingResidues: len - matching,
    helixStats: { ...hStats, predCount: hPred, expCount: hExp, truePositives: hTP },
    sheetStats: { ...eStats, predCount: ePred, expCount: eExp, truePositives: eTP },
    coilStats: { ...cStats, predCount: cPred, expCount: cExp, truePositives: cTP },
  };
}

