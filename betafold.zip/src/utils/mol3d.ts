/**
 * 3Dmol.js loader and utility manager for molecular visualization
 */

export function get3Dmol(): Promise<any> {
  if (typeof window === 'undefined') {
    return Promise.reject(new Error('Window not available'));
  }

  if ((window as any).$3Dmol) {
    return Promise.resolve((window as any).$3Dmol);
  }

  return new Promise((resolve, reject) => {
    // Check if script already exists in document
    const existing = document.querySelector('script[src*="3Dmol"]');
    if (existing) {
      const check = setInterval(() => {
        if ((window as any).$3Dmol) {
          clearInterval(check);
          resolve((window as any).$3Dmol);
        }
      }, 50);
      setTimeout(() => {
        clearInterval(check);
        if ((window as any).$3Dmol) resolve((window as any).$3Dmol);
        else reject(new Error('3Dmol loading timed out'));
      }, 6000);
      return;
    }

    const script = document.createElement('script');
    script.src = 'https://cdnjs.cloudflare.com/ajax/libs/3Dmol/2.5.5/3Dmol-min.js';
    script.async = true;
    script.onload = () => {
      if ((window as any).$3Dmol) {
        resolve((window as any).$3Dmol);
      } else {
        reject(new Error('3Dmol script loaded but global $3Dmol not defined'));
      }
    };
    script.onerror = () => reject(new Error('Failed to load 3Dmol script'));
    document.head.appendChild(script);
  });
}
